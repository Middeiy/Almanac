// Print the demo persona's forecast so the story can be tuned.
import { SAM } from '../src/data/personas'
import { learn } from '../src/engine/learn'
import { simulate, safeToSave } from '../src/engine/forecast'
const L = learn(SAM.history)
console.log('recurring', L.recurring.map(r => `${r.merchant}:${r.period}@${r.slot}:${r.median.toFixed(0)}`).join(', '))
console.log('everyday per dow', L.everyday.map(b => (b.reduce((a, c) => a + c, 0) / b.length).toFixed(0)).join(' '))
const f = simulate(SAM, L, { moves: new Set(), monthlySaving: 0 })
const low = f.days.reduce((w, d) => (d.p50 < w.p50 ? d : w))
console.log('pAny', f.pAnyNeg.toFixed(2), 'lowest p50', low.date.toDateString(), low.p50.toFixed(0), 'p10', low.p10.toFixed(0))
console.log('p50 every 7d', f.days.filter((_, i) => i % 7 === 0).map(d => `${d.date.getDate()}/${d.date.getMonth() + 1}:${d.p50.toFixed(0)}`).join(' '))
console.log('safe', safeToSave(SAM, L, new Set()))
const ov = [
  { match: (r: any) => r.merchant === 'EE', amount: -10, from: new Date(2026, 11, 1) },
  { match: (r: any) => r.merchant === 'BT Broadband', amount: -25, from: new Date(2026, 11, 1) },
  { match: (r: any) => r.merchant === 'Disney+', amount: 0, from: new Date(2026, 10, 9) },
]
for (const boost of [0, 250]) {
  const g = simulate(SAM, L, { moves: new Set(), monthlySaving: 0, overrides: ov, startBoost: boost })
  console.log('moves+boost', boost, 'pAny', g.pAnyNeg.toFixed(2), 'safe', safeToSave(SAM, L, new Set(), 0.1, { overrides: ov, startBoost: boost }))
}
