"""Checks on what the small model says. Pure Python, no model needed, so they are unit-tested.

A 0.6B model will happily invent a figure. Almanac's rule is that the model may only quote numbers the
forecast engine produced, so every money amount or percentage in a reply is checked against the facts
it was given. A reply that fails is thrown away and the app shows its built-in answer instead.
"""
from __future__ import annotations

import json
import re

_NUM = re.compile(r"(?P<cur>£)?\s?-?(?P<n>\d[\d,]*(?:\.\d+)?)(?P<pct>%)?")
_THINK = re.compile(r"<think>.*?</think>", re.S)

CATEGORIES = {"groceries", "dining", "travel", "shopping", "bills", "other"}
MAX_SPEND = 5000
HORIZON_DAYS = 90

# Wording that contradicts a decision the engine has already made.
_SAYS_YES = re.compile(r"go ahead|fine to spend|that'?s fine|no problem", re.I)
_SAYS_NO = re.compile(r"hold off|don'?t (?:spend|buy|do)|not spend|should not|shouldn'?t|wait (?:until|before)|avoid", re.I)


def _value(token: str) -> float:
    return abs(float(token.replace(",", "")))


def numbers_in(text: str) -> set[float]:
    return {_value(m["n"]) for m in _NUM.finditer(text)}


def ungrounded_numbers(output: str, allowed_text: str) -> list[str]:
    """Figures in `output` that are not in `allowed_text`.

    Money, percentages, decimals and anything over 31 must appear in the facts. Small bare integers
    (a date, "3 months") are let through, because the facts already carry the dates.
    """
    allowed = numbers_in(allowed_text)
    bad = []
    for m in _NUM.finditer(output):
        v = _value(m["n"])
        strict = bool(m["cur"] or m["pct"]) or "." in m["n"] or v > 31
        if strict and v not in allowed:
            bad.append(m.group(0).strip())
    return bad


def clean(text: str) -> str:
    """Strip reasoning tags and cut a reply that hit the token limit back to its last full sentence."""
    text = _THINK.sub("", text).strip()
    if text and text[-1] not in ".!?”\"":
        cut = max(text.rfind(". "), text.rfind("! "), text.rfind("? "), text.rfind(".\n"))
        text = text[: cut + 1] if cut > 40 else text
    return text.strip()


def contradicts(verdict: str | None, text: str) -> bool:
    if verdict == "hold":
        return bool(_SAYS_YES.search(text))
    if verdict == "go":
        return bool(_SAYS_NO.search(text))
    if verdict == "essential":
        return bool(re.search(r"hold off|skip|don'?t (?:buy|shop)|not spend", text, re.I))
    return False


def check_reply(text: str, facts: list[str], question: str, verdict: str | None = None) -> str | None:
    """Return why a reply is unusable, or None if it passes."""
    if len(text) < 20:
        return "too short"
    bad = ungrounded_numbers(text, "\n".join(facts) + "\n" + question)
    if bad:
        return "figures not in the forecast: " + ", ".join(bad)
    if contradicts(verdict, text):
        return f"contradicts the {verdict} decision"
    return None


def extract_json(text: str) -> dict | None:
    """First JSON object in the text. Small models sometimes wrap it in words or a code fence."""
    text = _THINK.sub("", text)
    dec = json.JSONDecoder()
    for i, ch in enumerate(text):
        if ch == "{":
            try:
                obj, _ = dec.raw_decode(text[i:])
            except ValueError:
                continue
            if isinstance(obj, dict):
                return obj
    return None


def _message_amount(message: str) -> float | None:
    m = re.search(r"£\s?(\d[\d,]*(?:\.\d{1,2})?)", message) or re.search(
        r"(\d[\d,]*(?:\.\d{1,2})?)\s*(?:pounds?|quid|gbp)\b", message, re.I
    )
    return _value(m.group(1)) if m else None


def validate_intent(obj: dict | None, message: str) -> dict:
    """Make the model's JSON safe to act on.

    The amount must be a number that is really in the person's message; otherwise it is replaced by the
    amount found there, or dropped (and the intent downgraded to "general"). The app then falls back to
    its own reading of the question.
    """
    obj = obj or {}
    kind = obj.get("intent") if obj.get("intent") in ("spend_check", "general") else "general"

    amount = obj.get("amount")
    if isinstance(amount, bool) or not isinstance(amount, (int, float)):
        amount = None
    if amount is not None and not (0 < amount <= MAX_SPEND and float(amount) in numbers_in(message)):
        amount = None
    if amount is None:
        amount = _message_amount(message)
    if amount is not None and not 0 < amount <= MAX_SPEND:
        amount = None
    if kind == "spend_check" and amount is None:
        kind = "general"

    category = obj.get("category") if obj.get("category") in CATEGORIES else "other"
    days = obj.get("days_from_now")
    days = days if isinstance(days, int) and not isinstance(days, bool) and 0 <= days < HORIZON_DAYS else 0
    return {
        "intent": kind,
        "amount": amount if kind == "spend_check" else None,
        "category": category,
        "days_from_now": days,
    }
