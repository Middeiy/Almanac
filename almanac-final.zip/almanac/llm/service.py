"""The two things the chat asks of the model. `llm` is anything with .generate(messages, max_new_tokens, temperature)."""
from __future__ import annotations

from guards import check_reply, clean, extract_json, validate_intent
from prompts import intent_messages, reply_messages


def parse_intent(llm, message: str) -> dict:
    raw = llm.generate(intent_messages(message), max_new_tokens=60, temperature=0.0)
    return validate_intent(extract_json(raw), message)


def write_reply(llm, payload: dict) -> dict:
    """Ask for the reply, check it against the engine's facts, retry once cooler, else give up.

    Returning text=None tells the app to use its built-in reply, which is built from the same numbers.
    """
    mode = payload.get("mode", "general")
    facts = [str(f) for f in payload.get("facts", [])]
    verdict = payload.get("verdict") if mode == "spend" else None
    history = payload.get("messages", [])[-6:]
    question = history[-1]["content"] if history else ""
    msgs = reply_messages(mode, history, facts, payload.get("verdictLine"))

    why = "no attempt"
    for temp in (0.4, 0.1):  # second attempt is close to greedy
        text = clean(llm.generate(msgs, max_new_tokens=200, temperature=temp))
        why = check_reply(text, facts, question, verdict)
        if why is None:
            return {"text": text}
    return {"text": None, "rejected": why}
