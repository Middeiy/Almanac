import { useEffect, useRef, useState } from 'react'
import { useApp, type Msg } from '../state'
import { askLive, CHIPS, greeting, reply, type ChatAction } from '../ai/chat'
import { animate, reducedMotion, stagger } from '../lib/motion'
import { money } from '../lib/format'
import { MiniChart } from './charts'

/* ---------- voice (Web Speech API; works in Chrome and Edge) ---------- */
const synth = typeof window !== 'undefined' ? window.speechSynthesis : undefined
function speakText(text: string) {
  if (!synth) return
  synth.cancel()
  const u = new SpeechSynthesisUtterance(text.replace(/£/g, ' pounds ').replace(/(\d),(\d)/g, '$1$2'))
  const v = synth.getVoices().find((x) => x.lang === 'en-GB')
  if (v) u.voice = v
  u.rate = 1.02
  synth.speak(u)
}
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const Recognition: any = typeof window !== 'undefined' ? (window as any).SpeechRecognition ?? (window as any).webkitSpeechRecognition : undefined

function TypeText({ text, onTick }: { text: string; onTick: () => void }) {
  const [n, setN] = useState(reducedMotion() ? text.length : 0)
  useEffect(() => {
    if (n >= text.length) return
    const id = requestAnimationFrame(() => { setN((x) => Math.min(text.length, x + Math.max(2, Math.ceil(text.length / 70)))); onTick() })
    return () => cancelAnimationFrame(id)
  }, [n, text, onTick])
  return <Lines text={text.slice(0, n)} />
}
const Lines = ({ text }: { text: string }) => <>{text.split('\n').map((l, i) => (l.trim() === '' ? <div key={i} className="h-2" /> : <p key={i}>{l}</p>))}</>

function Typing() {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (!ref.current || reducedMotion()) return
    const a = animate(ref.current.children, { translateY: [0, -4, 0], opacity: [0.4, 1, 0.4], duration: 900, delay: stagger(140), loop: true, ease: 'inOutSine' })
    return () => { a.pause() }
  }, [])
  return (
    <div ref={ref} className="flex w-fit gap-1.5 rounded-2xl rounded-bl-md bg-bg px-4 py-3.5" aria-label="Writing">
      {[0, 1, 2].map((i) => <span key={i} className="h-1.5 w-1.5 rounded-full bg-mute" />)}
    </div>
  )
}

export function Chat() {
  const app = useApp()
  const { messages, push, setView, complete, setAddOpen, onboarded, chatDraft, clearChatDraft, speak, setSpeak, ai } = app
  const [typing, setTyping] = useState(false)
  const [input, setInput] = useState('')
  const [mode, setMode] = useState<'live' | 'offline'>('offline')
  const [listening, setListening] = useState(false)
  const scroller = useRef<HTMLDivElement>(null)
  const snap = useRef(app)
  snap.current = app
  const toBottom = () => scroller.current?.scrollTo({ top: scroller.current.scrollHeight })

  const deliver = (m: Omit<Msg, 'id'>) => {
    push(m)
    if (snap.current.speak) speakText(m.text)
  }

  // greet after onboarding (and again after a reset)
  useEffect(() => {
    if (!onboarded || messages.length) return
    setTyping(true)
    const t = setTimeout(() => { setTyping(false); deliver({ role: 'assistant', ...greeting(snap.current) }) }, 1000)
    return () => clearTimeout(t)
  }, [onboarded, messages.length]) // eslint-disable-line

  useEffect(() => { toBottom() }, [messages.length, typing])
  useEffect(() => {
    const el = scroller.current?.lastElementChild
    if (el && !reducedMotion()) animate(el, { opacity: [0, 1], translateY: [8, 0], duration: 380, ease: 'outQuint' })
  }, [messages.length])

  const send = async (q: string) => {
    const text = q.trim()
    if (!text || typing) return
    setInput('')
    push({ role: 'user', text })
    setTyping(true)
    const history = [...snap.current.messages, { role: 'user' as const, text }].slice(-10).map((m) => ({ role: m.role, content: m.text }))
    const [live] = await Promise.all([askLive(history, snap.current), new Promise((r) => setTimeout(r, 650))])
    setTyping(false)
    // for a spend question the buttons and the numbers table come from the same forecast run the model was given
    const local = live?.tool ?? reply(text, snap.current)
    if (live) { setMode('live'); deliver({ role: 'assistant', text: live.text, actions: local.actions, rows: local.rows, chart: local.chart, live: true }) }
    else deliver({ role: 'assistant', ...local })
  }

  useEffect(() => { if (chatDraft) { send(chatDraft); clearChatDraft() } }, [chatDraft]) // eslint-disable-line

  const listen = () => {
    if (!Recognition) return
    const r = new Recognition()
    r.lang = 'en-GB'
    r.interimResults = true
    r.onresult = (e: { results: ArrayLike<{ 0: { transcript: string }; isFinal: boolean }> }) => {
      const res = Array.from(e.results)
      const t = res.map((x) => x[0].transcript).join('')
      setInput(t)
      if (res[res.length - 1].isFinal) { setListening(false); send(t) }
    }
    r.onend = () => setListening(false)
    r.onerror = () => setListening(false)
    setListening(true)
    try { r.start() } catch { setListening(false) }
  }

  const run = (a: ChatAction) => {
    if (a.go) setView(a.go)
    if (a.openAdd) setAddOpen(true)
    if (a.ask) send(a.ask)
    if (a.doId) {
      const act = snap.current.actions.find((x) => x.id === a.doId)
      if (!act || snap.current.done.has(a.doId)) return
      complete(a.doId)
      deliver({ role: 'assistant', text: act.yearly > 0
        ? `Done. That’s ${money(act.yearly)} a year, about ${money(act.yearly / 12)} a month, now counted in what you’ve saved. Your resilience score has gone up too.`
        : 'Done. I’ve re-run your forecast with that change. Your resilience score has gone up, and you may now have room to start saving each month.' })
    }
  }

  return (
    <aside className="flex h-full w-[340px] shrink-0 flex-col border-l border-line bg-surface min-[1400px]:w-[380px]">
      <div className="flex items-start justify-between border-b border-line px-5 py-4">
        <div>
          <p className="text-[15px] font-semibold">Your wealth manager</p>
          <p className="mt-0.5 flex items-center gap-1.5 text-[12.5px] text-mute">
            <span className={`h-1.5 w-1.5 rounded-full ${mode === 'live' || ai.state === 'online' ? 'bg-gain' : 'bg-[#98a2b3]'}`} />
            {mode === 'live' || ai.state === 'online' ? 'Qwen3 AI on this laptop, checked against your forecast' : ai.state === 'checking' ? 'Connecting…' : 'Answering from your data (AI server off)'}
          </p>
        </div>
        {synth && (
          <button onClick={() => { if (speak) synth.cancel(); setSpeak(!speak) }} aria-pressed={speak}
            className={`rounded-lg border px-2.5 py-1 text-[12px] font-medium ${speak ? 'border-brand bg-brand-soft text-brand' : 'border-line text-sub hover:text-ink'}`}>
            {speak ? 'Reading aloud' : 'Read aloud'}
          </button>
        )}
      </div>

      <div ref={scroller} className="thin-scroll flex-1 space-y-4 overflow-y-auto px-5 py-5">
        {messages.map((m, i) => <Bubble key={m.id} m={m} latest={i === messages.length - 1} onAction={run} onTick={toBottom} />)}
        {typing && <Typing />}
      </div>

      <div className="border-t border-line px-4 pt-3 pb-4">
        <div className="mb-3 flex flex-wrap gap-1.5">
          {CHIPS.map((c) => (
            <button key={c.label} onClick={() => send(c.q)} className="rounded-full border border-line px-2.5 py-1 text-[12px] text-sub hover:border-[#c7ccd4] hover:text-ink">{c.label}</button>
          ))}
        </div>
        <form onSubmit={(e) => { e.preventDefault(); send(input) }} className="flex items-center gap-2 rounded-xl border border-line px-3 focus-within:border-brand">
          <input value={input} onChange={(e) => setInput(e.target.value)} placeholder={listening ? 'Listening…' : 'Ask about your money'} aria-label="Message"
            className="h-11 min-w-0 flex-1 bg-transparent text-[14px] outline-none placeholder:text-mute focus-visible:outline-none" />
          {Recognition && (
            <button type="button" onClick={listen} aria-label="Speak your question"
              className={`rounded-lg px-2 py-1.5 text-[12.5px] font-medium ${listening ? 'bg-risk-soft text-risk' : 'text-sub hover:text-ink'}`}>
              {listening ? 'Stop' : 'Speak'}
            </button>
          )}
          <button type="submit" className="rounded-lg bg-ink px-3 py-1.5 text-[13px] font-medium text-white disabled:opacity-40" disabled={!input.trim() || typing}>Send</button>
        </form>
      </div>
    </aside>
  )
}

function Bubble({ m, latest, onAction, onTick }: { m: Msg; latest: boolean; onAction: (a: ChatAction) => void; onTick: () => void }) {
  if (m.role === 'user') return <div className="ml-auto w-fit max-w-[85%] rounded-2xl rounded-br-md bg-ink px-4 py-2.5 text-[14px] text-white">{m.text}</div>
  return (
    <div className="group max-w-[94%]">
      <div className="space-y-1 rounded-2xl rounded-bl-md bg-bg px-4 py-3 text-[14px] leading-relaxed">
        {latest ? <TypeText text={m.text} onTick={onTick} /> : <Lines text={m.text} />}
        {m.chart && <div className="mt-2 rounded-lg bg-surface p-2"><MiniChart series={m.chart} /></div>}
        {m.rows && (
          <table className="mt-2 w-full text-[13px]">
            <tbody>
              {m.rows.map(([a, b], i) => (
                <tr key={i} className="border-t border-line">
                  <td className="py-1.5 pr-3 text-sub">{a}</td>
                  <td className="tnum py-1.5 text-right font-medium">{b}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      <div className="mt-2 flex flex-wrap items-center gap-2">
        {m.actions?.map((a) => (
          <button key={a.label} onClick={() => onAction(a)} className="rounded-lg border border-line bg-surface px-3 py-1.5 text-[12.5px] font-medium text-brand hover:border-brand">{a.label}</button>
        ))}
        {synth && <button onClick={() => speakText(m.text)} className="px-1 text-[12px] text-mute opacity-0 transition-opacity group-hover:opacity-100 hover:text-ink">Listen</button>}
      </div>
    </div>
  )
}
