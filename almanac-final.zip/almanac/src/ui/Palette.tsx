import { useEffect, useMemo, useRef, useState } from 'react'
import { useApp, type View } from '../state'
import { money } from '../lib/format'

interface Item { id: string; label: string; hint: string; run: () => void }

/** ⌘K / Ctrl+K: jump anywhere, take an action, or ask the wealth manager. */
export function Palette() {
  const app = useApp()
  const { paletteOpen, setPaletteOpen } = app
  const [q, setQ] = useState('')
  const [i, setI] = useState(0)
  const input = useRef<HTMLInputElement>(null)

  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); setPaletteOpen(!paletteOpen) }
      if (e.key === 'Escape') setPaletteOpen(false)
    }
    window.addEventListener('keydown', k)
    return () => window.removeEventListener('keydown', k)
  }, [paletteOpen, setPaletteOpen])
  useEffect(() => { if (paletteOpen) { setQ(''); setI(0); setTimeout(() => input.current?.focus(), 10) } }, [paletteOpen])

  const items = useMemo<Item[]>(() => {
    const views: [View, string][] = [['overview', 'Overview'], ['time', 'Time machine'], ['savings', 'Savings and discounts'], ['cards', 'Cards and points'], ['invest', 'Investments and cash'], ['trust', 'Privacy and safety'], ['how', 'How it works']]
    return [
      ...views.map(([v, l]) => ({ id: `v-${v}`, label: l, hint: 'Go to', run: () => app.setView(v) })),
      ...app.actions.filter((a) => !app.done.has(a.id) && (a.yearly > 0 || a.startBoost)).map((a) => ({
        id: `a-${a.id}`, label: a.title, hint: a.yearly > 0 ? `Do it, ${money(a.yearly)}/yr` : 'Do it', run: () => { app.complete(a.id); setPaletteOpen(false) },
      })),
      { id: 'card', label: 'Add a card', hint: 'Cards', run: () => { app.setView('cards'); app.setAddOpen(true) } },
      { id: 'simple', label: app.simple ? 'Turn off simple view' : 'Turn on simple view', hint: 'Accessibility', run: () => { app.setSimple(!app.simple); setPaletteOpen(false) } },
      { id: 'large', label: app.large ? 'Normal text size' : 'Larger text', hint: 'Accessibility', run: () => { app.setLarge(!app.large); setPaletteOpen(false) } },
      { id: 'reset', label: 'Reset the demo', hint: 'Demo', run: () => { app.resetDemo(); setPaletteOpen(false) } },
    ]
  }, [app, setPaletteOpen])

  const shown = items.filter((x) => x.label.toLowerCase().includes(q.toLowerCase()))
  const ask: Item | null = q.trim().length > 2 ? { id: 'ask', label: `Ask: “${q.trim()}”`, hint: 'Wealth manager', run: () => app.askChat(q.trim()) } : null
  const all = ask ? [...shown, ask] : shown

  if (!paletteOpen) return null
  return (
    <div className="fixed inset-0 z-[70] flex items-start justify-center pt-[14vh]" role="dialog" aria-modal="true" aria-label="Search or ask">
      <button aria-label="Close" className="absolute inset-0 bg-[#101828]/40" onClick={() => setPaletteOpen(false)} />
      <div className="relative w-full max-w-[560px] overflow-hidden rounded-2xl bg-surface shadow-2xl">
        <input ref={input} value={q} onChange={(e) => { setQ(e.target.value); setI(0) }}
          onKeyDown={(e) => {
            if (e.key === 'ArrowDown') { e.preventDefault(); setI((x) => Math.min(all.length - 1, x + 1)) }
            if (e.key === 'ArrowUp') { e.preventDefault(); setI((x) => Math.max(0, x - 1)) }
            if (e.key === 'Enter' && all[i]) all[i].run()
          }}
          placeholder="Go to a page, do an action, or ask a question"
          className="h-14 w-full border-b border-line px-5 text-[15px] outline-none focus-visible:outline-none" aria-label="Search or ask" />
        <ul className="thin-scroll max-h-[50vh] overflow-y-auto p-2" role="listbox">
          {all.map((x, k) => (
            <li key={x.id} role="option" aria-selected={k === i}>
              <button onMouseEnter={() => setI(k)} onClick={x.run}
                className={`flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-left text-[14px] ${k === i ? 'bg-brand-soft text-brand' : 'text-ink'}`}>
                <span>{x.label}</span><span className="text-[12px] text-mute">{x.hint}</span>
              </button>
            </li>
          ))}
          {!all.length && <li className="px-3 py-3 text-[14px] text-mute">Type a question to ask your wealth manager.</li>}
        </ul>
        <p className="border-t border-line px-5 py-2 text-[12px] text-mute">↑ ↓ to move, Enter to choose, Esc to close</p>
      </div>
    </div>
  )
}
