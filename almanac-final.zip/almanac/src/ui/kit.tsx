import { useEffect, useRef, type ReactNode } from 'react'
import { animate, countTo, reducedMotion } from '../lib/motion'

export function Panel({ title, aside, children, className = '' }: { title?: ReactNode; aside?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={`rounded-2xl border border-line bg-surface p-5 ${className}`}>
      {(title || aside) && (
        <div className="mb-4 flex items-baseline justify-between gap-4">
          {title && <h2 className="text-[15px] font-semibold">{title}</h2>}
          {aside && <div className="text-[13px] text-mute">{aside}</div>}
        </div>
      )}
      {children}
    </section>
  )
}

/** Number that animates from its previous value. `fmt` must be a stable function. */
export function Figure({ value, fmt, className = '' }: { value: number; fmt: (n: number) => string; className?: string }) {
  const ref = useRef<HTMLSpanElement>(null)
  const last = useRef(0)
  useEffect(() => {
    countTo(ref.current, last.current, value, fmt, 900)
    last.current = value
  }, [value, fmt])
  return <span ref={ref} className={`tnum ${className}`}>{fmt(0)}</span>
}

export function Button({ children, onClick, variant = 'primary', size = 'md', type = 'button', className = '' }: {
  children: ReactNode; onClick?: () => void; variant?: 'primary' | 'secondary' | 'ghost' | 'done'; size?: 'sm' | 'md'; type?: 'button' | 'submit'; className?: string
}) {
  const v = {
    primary: 'bg-ink text-white hover:bg-[#1d2939]',
    secondary: 'border border-line bg-surface text-ink hover:border-[#c7ccd4]',
    ghost: 'text-brand hover:bg-brand-soft',
    done: 'bg-gain-soft text-gain',
  }[variant]
  const s = size === 'sm' ? 'h-8 px-3 text-[13px]' : 'h-10 px-4 text-[14px]'
  return (
    <button type={type} onClick={onClick} className={`inline-flex shrink-0 items-center justify-center gap-1.5 rounded-lg font-medium transition-colors ${v} ${s} ${className}`}>
      {children}
    </button>
  )
}

export function Stat({ label, children, note, tone = 'ink' }: { label: string; children: ReactNode; note?: ReactNode; tone?: 'ink' | 'gain' | 'brand' | 'risk' }) {
  const color = { ink: 'text-ink', gain: 'text-gain', brand: 'text-brand', risk: 'text-risk' }[tone]
  return (
    <div className="min-w-0 rounded-2xl border border-line bg-surface px-4 py-4 min-[1400px]:px-5">
      <p className="text-[13px] text-mute">{label}</p>
      <p className={`figure mt-2 whitespace-nowrap text-[26px] min-[1400px]:text-[30px] ${color}`}>{children}</p>
      {note && <p className="mt-2 text-[12.5px] leading-snug text-mute">{note}</p>}
    </div>
  )
}

export function Modal({ open, onClose, title, children }: { open: boolean; onClose: () => void; title: string; children: ReactNode }) {
  const box = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (open && box.current && !reducedMotion()) animate(box.current, { opacity: [0, 1], translateY: [12, 0], scale: [0.98, 1], duration: 380, ease: 'outQuint' })
  }, [open])
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', k)
    return () => window.removeEventListener('keydown', k)
  }, [onClose])
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6" role="dialog" aria-modal="true" aria-label={title}>
      <button aria-label="Close" className="absolute inset-0 bg-[#101828]/40" onClick={onClose} />
      <div ref={box} className="thin-scroll relative max-h-[90vh] w-full max-w-[560px] overflow-y-auto rounded-2xl bg-surface p-6 shadow-2xl">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="text-[18px] font-semibold">{title}</h2>
          <button onClick={onClose} className="rounded-md px-2 py-1 text-[13px] text-mute hover:bg-line-2">Close</button>
        </div>
        {children}
      </div>
    </div>
  )
}

export function Progress({ value, tone = '#4b2a86' }: { value: number; tone?: string }) {
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-line-2">
      <div className="h-full rounded-full transition-[width] duration-700" style={{ width: `${Math.min(100, Math.max(0, value * 100))}%`, background: tone }} />
    </div>
  )
}

export function Badge({ children, tone = 'mute' }: { children: ReactNode; tone?: 'mute' | 'gain' | 'risk' | 'brand' }) {
  const t = { mute: 'bg-line-2 text-sub', gain: 'bg-gain-soft text-gain', risk: 'bg-risk-soft text-risk', brand: 'bg-brand-soft text-brand' }[tone]
  return <span className={`inline-flex items-center rounded-md px-2 py-0.5 text-[12px] font-medium ${t}`}>{children}</span>
}
