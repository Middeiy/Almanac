import { useEffect } from 'react'
import { useApp, type View } from '../state'

/** Speaker notes for the demo. Press N (outside a text box) to show or hide. Only the presenter needs to see this. */
const NOTES: Record<View, { say: string; click: string; ask?: string }> = {
  overview: {
    say: 'Sam earns £24k as a healthcare assistant. Score 38, Fragile: a 1 in 5 chance of going overdrawn at Christmas and £766 a year leaking. Nobody has ever looked at his whole picture.',
    click: 'Spend checker: £100, going out, Today → Check it. Then "What should I do first?" → in the chat, "Do it: £250 cushion". Watch the score jump.',
    ask: 'Why these score weights? Ordered by priority, not yet calibrated; next step is fitting them to real missed-payment data.',
  },
  time: {
    say: 'This is financial time travel. 400 simulated futures from his real spending. Heads-ups arrive before the problem, not after.',
    click: 'Play the next 90 days (notifications pop). Turn on "Bank shifts stop" and "£400 repair". Then Next 10 years.',
    ask: 'Is the 10-year line a promise? No: an illustration, 5% after inflation, capital at risk, shown on screen.',
  },
  savings: {
    say: 'Every saving comes from his own transactions and links to them. "Do it for me" gives the exact words for the phone call.',
    click: 'Broadband → Do it for me. Then Mark as done → Undo exists.',
  },
  cards: {
    say: 'It only optimises cards you already have. Recommending new credit would be credit broking, so it never does.',
    click: 'Add a card → Aurora Rewards → Add card. The chat explains what the points are worth.',
    ask: 'What if someone carries a balance? Rewards switch off for that card and it says to clear the debt first.',
  },
  invest: {
    say: 'Same order a wealth manager uses: emergency fund, free money (25% Lifetime ISA bonus), then a global index fund. Never names a fund.',
    click: 'Slide the monthly amount. Point at the capital-at-risk box.',
  },
  trust: {
    say: 'Guidance, not advice: it would run under a bank’s FCA targeted support permission. Read-only Open Banking, data download and delete, free debt help.',
    click: 'Scroll to "If money gets hard".',
  },
  how: {
    say: 'The AI never does the maths. The engine decides; Qwen 0.6B on this laptop writes the words; a checker rejects any number the engine didn’t produce.',
    click: 'Point at the guard example and the test counts.',
    ask: 'Why a small model? Private, free, fast; the guard is what makes it safe, not the model size.',
  },
}

export function Notes() {
  const { notes, setNotes, view } = useApp()
  useEffect(() => {
    const k = (e: KeyboardEvent) => {
      const t = e.target as HTMLElement
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.tagName === 'SELECT')) return
      if (e.key.toLowerCase() === 'n' && !e.metaKey && !e.ctrlKey) setNotes(!notes)
    }
    window.addEventListener('keydown', k)
    return () => window.removeEventListener('keydown', k)
  }, [notes, setNotes])
  if (!notes) return null
  const n = NOTES[view]
  return (
    <div className="fixed bottom-5 left-[236px] z-[55] w-[440px] rounded-2xl bg-[#101828]/95 p-4 text-[13px] leading-relaxed text-white shadow-2xl">
      <div className="mb-2 flex items-center justify-between">
        <p className="text-[12px] font-semibold text-[#5EE0B5]">Speaker notes</p>
        <button onClick={() => setNotes(false)} className="text-[12px] text-white/60 hover:text-white">Hide (N)</button>
      </div>
      <p><span className="text-white/60">Say: </span>{n.say}</p>
      <p className="mt-1.5"><span className="text-white/60">Click: </span>{n.click}</p>
      {n.ask && <p className="mt-1.5"><span className="text-white/60">If asked: </span>{n.ask}</p>}
    </div>
  )
}
