import { useEffect, useRef, useState } from 'react'
import type { DayStat } from '../engine/forecast'
import type { MiniSeries } from '../ai/whatif'
import { dayLabel, money, pct } from '../lib/format'
import { reducedMotion } from '../lib/motion'

/** Tween numeric fields between forecasts so changes are visible, not a jump. */
function useTween(days: DayStat[], ms = 700) {
  const [view, setView] = useState(days)
  const from = useRef(days)
  useEffect(() => {
    if (reducedMotion()) { setView(days); from.current = days; return }
    const a = from.current
    const t0 = performance.now()
    let raf = 0
    const keys = ['p10', 'p50', 'p90', 'pNeg'] as const
    const step = (t: number) => {
      const k = Math.min(1, (t - t0) / ms)
      const e = 1 - Math.pow(1 - k, 4)
      setView(days.map((d, i) => {
        const o = { ...d }
        const s = a[i] ?? d
        keys.forEach((key) => { o[key] = s[key] + (d[key] - s[key]) * e })
        return o
      }))
      if (k < 1) raf = requestAnimationFrame(step)
      else from.current = days
    }
    raf = requestAnimationFrame(step)
    return () => { cancelAnimationFrame(raf); from.current = days }
  }, [days, ms])
  return view
}

/** Measure a container so charts draw at real pixel size (text stays legible). */
function useWidth(fallback = 720) {
  const ref = useRef<HTMLDivElement>(null)
  const [w, setW] = useState(fallback)
  useEffect(() => {
    if (!ref.current) return
    const ro = new ResizeObserver(([e]) => setW(Math.max(280, Math.round(e.contentRect.width))))
    ro.observe(ref.current)
    return () => ro.disconnect()
  }, [])
  return [ref, w] as const
}

function ticksFor(lo: number, hi: number) {
  const raw = (hi - lo) / 5
  const mag = Math.pow(10, Math.floor(Math.log10(raw)))
  const step = [1, 2, 2.5, 5, 10].map((m) => m * mag).find((s) => s >= raw) ?? 10 * mag
  const out: number[] = []
  for (let v = Math.ceil(lo / step) * step; v <= hi; v += step) out.push(v)
  return out
}
const k = (v: number) => (Math.abs(v) >= 1000 ? `£${(v / 1000).toFixed(v % 1000 === 0 ? 0 : 1)}k` : `£${v}`)

/**
 * Balance forecast. Median line, 10–90% band. Optional dashed "before" line
 * so the effect of actions is visible.
 */
export function ForecastChart({ days, before, height = 240, cursor, beforeLabel = 'Before your actions', marks }: { days: DayStat[]; before?: DayStat[]; height?: number; cursor?: number; beforeLabel?: string; marks?: { day: number; tone: string }[] }) {
  const view = useTween(days)
  const [box, W] = useWidth()
  const H = height
  const pad = { l: 48, r: 12, t: 12, b: 26 }
  const [hover, setHover] = useState<number | null>(null)
  const ref = useRef<SVGSVGElement>(null)
  const all = [...days, ...(before ?? [])]
  const lo = Math.min(-100, ...all.map((d) => d.p10)) * 1.05
  const hi = Math.max(500, ...all.map((d) => d.p90)) * 1.05
  const x = (i: number) => pad.l + (i / (days.length - 1)) * (W - pad.l - pad.r)
  const y = (v: number) => pad.t + ((hi - v) / (hi - lo)) * (H - pad.t - pad.b)
  const line = (ds: DayStat[], key: 'p10' | 'p50' | 'p90') => ds.map((d, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(d[key]).toFixed(1)}`).join('')
  const band = line(view, 'p90') + [...view].reverse().map((d, j) => `L${x(view.length - 1 - j).toFixed(1)},${y(d.p10).toFixed(1)}`).join('') + 'Z'
  const hd = hover !== null ? view[hover] : null

  return (
    <div className="relative" ref={box}>
      <svg ref={ref} viewBox={`0 0 ${W} ${H}`} className="w-full touch-none" role="img" aria-label="Balance forecast with likely range"
        onPointerMove={(e) => {
          const r = ref.current!.getBoundingClientRect()
          const px = ((e.clientX - r.left) / r.width) * W
          setHover(Math.max(0, Math.min(days.length - 1, Math.round(((px - pad.l) / (W - pad.l - pad.r)) * (days.length - 1)))))
        }}
        onPointerLeave={() => setHover(null)}>
        <rect x={pad.l} y={y(0)} width={W - pad.l - pad.r} height={Math.max(0, y(lo) - y(0))} fill="#B42318" opacity="0.05" />
        {ticksFor(lo, hi).map((v) => (
          <g key={v}>
            <line x1={pad.l} x2={W - pad.r} y1={y(v)} y2={y(v)} stroke={v === 0 ? '#B42318' : '#EEF0F3'} strokeOpacity={v === 0 ? 0.5 : 1} strokeDasharray={v === 0 ? '4 4' : undefined} />
            <text x={pad.l - 8} y={y(v) + 4} textAnchor="end" fontSize="11" fill="#667085">{k(v)}</text>
          </g>
        ))}
        {days.filter((d) => d.date.getDate() === 1).map((d) => (
          <text key={d.i} x={x(d.i)} y={H - 6} textAnchor="middle" fontSize="11" fill="#667085">{d.date.toLocaleDateString('en-GB', { month: 'short' })}</text>
        ))}
        <path d={band} fill="#4B2A86" opacity="0.10" />
        {before && <path d={line(before, 'p50')} fill="none" stroke="#98A2B3" strokeWidth="1.5" strokeDasharray="5 4" />}
        <path d={line(view, 'p50')} fill="none" stroke="#4B2A86" strokeWidth="2" strokeLinejoin="round" />
        {marks?.map((m) => (
          <circle key={`${m.day}-${m.tone}`} cx={x(m.day)} cy={H - pad.b + 1} r="4" fill={m.tone === 'warn' ? '#B42318' : m.tone === 'good' ? '#067A55' : '#4B2A86'} stroke="#fff" strokeWidth="1.5" />
        ))}
        {cursor !== undefined && view[cursor] && (
          <g>
            <line x1={x(cursor)} x2={x(cursor)} y1={pad.t} y2={H - pad.b} stroke="#4B2A86" strokeWidth="1.5" />
            <circle cx={x(cursor)} cy={y(view[cursor].p50)} r="6" fill="#4B2A86" stroke="#fff" strokeWidth="2.5" />
          </g>
        )}
        {hd && (
          <g>
            <line x1={x(hover!)} x2={x(hover!)} y1={pad.t} y2={H - pad.b} stroke="#101828" strokeOpacity="0.4" />
            <circle cx={x(hover!)} cy={y(hd.p50)} r="4.5" fill="#4B2A86" stroke="#fff" strokeWidth="2" />
          </g>
        )}
      </svg>
      {hd && (
        <div className="pointer-events-none absolute top-1 rounded-lg border border-line bg-surface px-3 py-2 text-[12.5px] leading-relaxed shadow-lg"
          style={{ left: `clamp(0px, calc(${(x(hover!) / W) * 100}% + 12px), calc(100% - 190px))` }}>
          <p className="font-semibold">{dayLabel(hd.date)}</p>
          <p className="tnum">Likely {money(hd.p50)}</p>
          <p className="tnum text-mute">Range {money(hd.p10)} to {money(hd.p90)}</p>
          <p className={`tnum ${hd.pNeg >= 0.05 ? 'text-risk' : 'text-mute'}`}>{pct(hd.pNeg)} chance below £0</p>
        </div>
      )}
      <div className="mt-2 flex gap-5 text-[12px] text-mute">
        <span className="flex items-center gap-1.5"><span className="h-0.5 w-4 bg-brand" />Likely balance</span>
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-4 rounded-sm bg-brand/15" />8 in 10 outcomes</span>
        {before && <span className="flex items-center gap-1.5"><span className="h-0 w-4 border-t-[1.5px] border-dashed border-[#98A2B3]" />{beforeLabel}</span>}
      </div>
    </div>
  )
}

export function GrowthChart({ rows }: { rows: { year: number; p10: number; p50: number; p90: number; paidIn: number }[] }) {
  const [box, W] = useWidth()
  const H = 240
  const pad = { l: 52, r: 12, t: 14, b: 26 }
  const hi = Math.max(...rows.map((r) => r.p90)) * 1.08 || 1
  const pts = [{ year: 0, p10: 0, p50: 0, p90: 0, paidIn: 0 }, ...rows]
  const x = (i: number) => pad.l + (i / rows.length) * (W - pad.l - pad.r)
  const y = (v: number) => pad.t + (1 - v / hi) * (H - pad.t - pad.b)
  const path = (key: 'p10' | 'p50' | 'p90' | 'paidIn') => pts.map((r, i) => `${i ? 'L' : 'M'}${x(i)},${y(r[key])}`).join('')
  const band = path('p90') + [...pts].reverse().map((r, j) => `L${x(pts.length - 1 - j)},${y(r.p10)}`).join('') + 'Z'
  const last = rows[rows.length - 1]
  return (
    <div ref={box}>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label={`After 10 years, likely ${money(last.p50)} from ${money(last.paidIn)} paid in`}>
        {ticksFor(0, hi).map((v) => (
          <g key={v}>
            <line x1={pad.l} x2={W - pad.r} y1={y(v)} y2={y(v)} stroke="#EEF0F3" />
            <text x={pad.l - 8} y={y(v) + 4} fontSize="11" textAnchor="end" fill="#667085">{k(v)}</text>
          </g>
        ))}
        {[0, 2, 4, 6, 8, 10].map((yr) => <text key={yr} x={x(yr)} y={H - 6} fontSize="11" textAnchor="middle" fill="#667085">{yr === 0 ? 'Now' : `${yr}y`}</text>)}
        <path d={band} fill="#067A55" opacity="0.12" />
        <path d={path('paidIn')} fill="none" stroke="#98A2B3" strokeWidth="1.5" strokeDasharray="5 4" />
        <path d={path('p50')} fill="none" stroke="#067A55" strokeWidth="2" />
        <text x={x(10) - 4} y={y(last.p50) - 8} fontSize="12" textAnchor="end" fill="#101828" fontWeight="600">Likely {money(last.p50)}</text>
        <text x={x(10) - 4} y={y(last.paidIn) + 16} fontSize="11.5" textAnchor="end" fill="#667085">You pay in {money(last.paidIn)}</text>
      </svg>
      <div className="mt-2 flex gap-5 text-[12px] text-mute">
        <span className="flex items-center gap-1.5"><span className="h-0.5 w-4 bg-gain" />Likely value, after inflation</span>
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-4 rounded-sm bg-gain/15" />8 in 10 outcomes</span>
        <span className="flex items-center gap-1.5"><span className="h-0 w-4 border-t-[1.5px] border-dashed border-[#98A2B3]" />Paid in</span>
      </div>
    </div>
  )
}

/** Two futures, 10 years: "if nothing changes" vs "with the plan" (median + 10–90% band). */
export function FuturesChart({ rows, cursorYear }: { rows: { month: number; p10: number; p50: number; p90: number; without: number }[]; cursorYear: number }) {
  const [box, W] = useWidth()
  const H = 300
  const pad = { l: 56, r: 16, t: 16, b: 28 }
  const hi = Math.max(...rows.map((r) => r.p90)) * 1.06
  const maxM = rows[rows.length - 1].month
  const x = (m: number) => pad.l + (m / maxM) * (W - pad.l - pad.r)
  const y = (v: number) => pad.t + (1 - v / hi) * (H - pad.t - pad.b)
  const path = (k: 'p10' | 'p50' | 'p90' | 'without') => rows.map((r, i) => `${i ? 'L' : 'M'}${x(r.month).toFixed(1)},${y(r[k]).toFixed(1)}`).join('')
  const band = path('p90') + [...rows].reverse().map((r) => `L${x(r.month).toFixed(1)},${y(r.p10).toFixed(1)}`).join('') + 'Z'
  const cm = cursorYear * 12
  const at = rows.reduce((b, r) => (Math.abs(r.month - cm) < Math.abs(b.month - cm) ? r : b))
  const ref = useRef<SVGPathElement>(null)
  useEffect(() => {
    const p = ref.current
    if (!p || reducedMotion()) return
    const len = p.getTotalLength()
    p.style.strokeDasharray = `${len}`
    p.style.strokeDashoffset = `${len}`
    p.getBoundingClientRect()
    p.style.transition = 'stroke-dashoffset 1600ms cubic-bezier(.2,.7,.2,1)'
    p.style.strokeDashoffset = '0'
  }, [W])
  return (
    <div ref={box}>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label={`In ${cursorYear} years: with the plan about ${money(at.p50)}, if nothing changes ${money(at.without)}`}>
        {ticksFor(0, hi).map((v) => (
          <g key={v}>
            <line x1={pad.l} x2={W - pad.r} y1={y(v)} y2={y(v)} stroke="rgba(255,255,255,.08)" />
            <text x={pad.l - 8} y={y(v) + 4} fontSize="11" textAnchor="end" fill="#B9AED3">{k(v)}</text>
          </g>
        ))}
        {[0, 2, 4, 6, 8, 10].map((yr) => <text key={yr} x={x(yr * 12)} y={H - 8} fontSize="11" textAnchor="middle" fill="#B9AED3">{yr === 0 ? 'Today' : `${2026 + yr}`}</text>)}
        <path d={band} fill="#5EE0B5" opacity="0.14" />
        <path d={path('without')} fill="none" stroke="#8C7DAD" strokeWidth="2" strokeDasharray="6 5" />
        <path ref={ref} d={path('p50')} fill="none" stroke="#5EE0B5" strokeWidth="2.5" strokeLinejoin="round" />
        <line x1={x(at.month)} x2={x(at.month)} y1={pad.t} y2={H - pad.b} stroke="#fff" strokeOpacity="0.5" />
        <circle cx={x(at.month)} cy={y(at.p50)} r="6" fill="#5EE0B5" stroke="#24123F" strokeWidth="2.5" />
        <circle cx={x(at.month)} cy={y(at.without)} r="5" fill="#8C7DAD" stroke="#24123F" strokeWidth="2.5" />
      </svg>
      <div className="mt-2 flex gap-5 text-[12px] text-[#B9AED3]">
        <span className="flex items-center gap-1.5"><span className="h-0.5 w-4 bg-[#5EE0B5]" />With the plan (likely)</span>
        <span className="flex items-center gap-1.5"><span className="h-2.5 w-4 rounded-sm bg-[#5EE0B5]/20" />8 in 10 outcomes</span>
        <span className="flex items-center gap-1.5"><span className="h-0 w-4 border-t-2 border-dashed border-[#8C7DAD]" />If nothing changes</span>
      </div>
    </div>
  )
}

/** Small before/after balance chart, drawn inside chat replies and the spend checker. */
export function MiniChart({ series, height = 96, afterLabel = 'If you spend it' }: { series: MiniSeries; height?: number; afterLabel?: string }) {
  const [box, W] = useWidth(300)
  const H = height
  const pad = { l: 34, r: 6, t: 6, b: 16 }
  const all = [...series.before, ...series.after]
  const lo = Math.min(-50, ...all) * 1.08
  const hi = Math.max(200, ...all) * 1.05
  const n = series.before.length
  const x = (i: number) => pad.l + (i / (n - 1)) * (W - pad.l - pad.r)
  const y = (v: number) => pad.t + ((hi - v) / (hi - lo)) * (H - pad.t - pad.b)
  const line = (a: number[]) => a.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join('')
  const ref = useRef<SVGPathElement>(null)
  useEffect(() => {
    const p = ref.current
    if (!p || reducedMotion()) return
    const len = p.getTotalLength()
    p.style.strokeDasharray = `${len}`
    p.style.strokeDashoffset = `${len}`
    p.getBoundingClientRect()
    p.style.transition = 'stroke-dashoffset 1100ms cubic-bezier(.2,.7,.2,1)'
    p.style.strokeDashoffset = '0'
  }, [series, W])
  const minAfter = series.after.reduce((m, v, i) => (v < series.after[m] ? i : m), 0)
  return (
    <div ref={box}>
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="Likely balance with and without the spend">
        <rect x={pad.l} y={y(0)} width={W - pad.l - pad.r} height={Math.max(0, y(lo) - y(0))} fill="#B42318" opacity="0.06" />
        <line x1={pad.l} x2={W - pad.r} y1={y(0)} y2={y(0)} stroke="#B42318" strokeOpacity="0.5" strokeDasharray="3 3" />
        <text x={pad.l - 5} y={y(0) + 3.5} fontSize="9.5" textAnchor="end" fill="#667085">£0</text>
        <text x={pad.l - 5} y={pad.t + 8} fontSize="9.5" textAnchor="end" fill="#667085">{k(Math.round(hi / 100) * 100)}</text>
        <path d={line(series.before)} fill="none" stroke="#98A2B3" strokeWidth="1.5" strokeDasharray="4 3" />
        <path ref={ref} d={line(series.after)} fill="none" stroke="#4B2A86" strokeWidth="2" strokeLinejoin="round" />
        <line x1={x(series.mark)} x2={x(series.mark)} y1={pad.t} y2={H - pad.b} stroke="#4B2A86" strokeOpacity="0.35" />
        <circle cx={x(minAfter)} cy={y(series.after[minAfter])} r="3.5" fill={series.after[minAfter] < 0 ? '#B42318' : '#4B2A86'} stroke="#fff" strokeWidth="1.5" />
        {series.dates.map((d, i) => d.getDate() === 1 && <text key={i} x={x(i)} y={H - 3} fontSize="9.5" textAnchor="middle" fill="#667085">{d.toLocaleDateString('en-GB', { month: 'short' })}</text>)}
      </svg>
      <div className="mt-1 flex gap-4 text-[11px] text-mute">
        <span className="flex items-center gap-1"><span className="h-0.5 w-3 bg-brand" />{afterLabel}</span>
        <span className="flex items-center gap-1"><span className="h-0 w-3 border-t-[1.5px] border-dashed border-[#98A2B3]" />If you don’t</span>
      </div>
    </div>
  )
}
