// The wealth manager's voice.
// Every answer is assembled from the same engine numbers the dashboard shows, so the
// chat can never contradict the screen. If a live model is connected (see server/),
// the local Qwen3 model (see llm/) gets the same facts and the same rules, and this file becomes the fallback.
//
// Live flow for a question like "should I spend £100 tonight?":
//   1. Qwen reads the question into { intent, amount, category, when }      POST /api/intent
//   2. whatif.ts re-runs the forecast with that spend added                 (here, in the browser)
//   3. Qwen turns the numbers into a recommendation                         POST /api/chat
// If the server is off, slow, or its answer quotes a number the engine never produced, the built-in
// reply below is used instead, from the same numbers.
import { CATEGORY_LABEL, type Category } from '../engine/cards'
import { dayLabel, money, money2, pct } from '../lib/format'
import type { Snapshot, View } from '../state'
import { categoryOf, intentFromModel, parseSpend, runWhatIf, VERDICT_LINE, whatIfFacts, whatIfReply, type MiniSeries, type SpendIntent } from './whatif'

export interface ChatAction { label: string; go?: View; doId?: string; openAdd?: boolean; ask?: string }
export interface Reply { text: string; rows?: [string, string][]; actions?: ChatAction[]; chart?: MiniSeries }

export const SUGGESTIONS = [
  'How much have I saved this month?',
  'What are my points worth?',
  'Which card should I use for groceries?',
  'Can I afford to invest?',
  'Will I run short before payday?',
  'Any discounts I’m missing?',
  'Where could my points take me?',
]
export const CHIPS: { label: string; q: string }[] = [
  { label: 'Saved this month', q: SUGGESTIONS[0] },
  { label: 'Points worth', q: SUGGESTIONS[1] },
  { label: 'Best card', q: 'Which card should I use for each kind of spending?' },
  { label: 'Can I invest?', q: SUGGESTIONS[3] },
  { label: 'Run short?', q: SUGGESTIONS[4] },
  { label: 'Discounts', q: SUGGESTIONS[5] },
  { label: 'Trip on points', q: SUGGESTIONS[6] },
  { label: '£100 tonight?', q: 'Hey, I want to spend 100 pounds out tonight. Should I do this?' },
  { label: '£50 groceries?', q: 'Is it worth it to spend 50 pounds on groceries?' },
]

const lowest = (s: Snapshot) => s.forecast.days.slice(0, 60).reduce((w, d) => (d.p50 < w.p50 ? d : w))
const worstRisk = (s: Snapshot) => s.forecast.days.reduce((w, d) => (d.pNeg > w.pNeg ? d : w))

export function greeting(s: Snapshot): Reply {
  const pts = s.progs.reduce((a, p) => a + p.best, 0)
  const risk = worstRisk(s)
  return {
    text: `Hi ${s.persona.name}. I’ve gone through your last 90 days of transactions, your cards and your points. Three things stand out:\n\n1. There’s about ${money(s.potentialYearly)} a year you’re leaving on the table, mostly bills and card rewards.\n2. Your points are worth up to ${money(pts)} if you use them well.\n3. ${risk.pNeg >= 0.1 ? `Christmas week is tight. There’s a ${pct(risk.pNeg)} chance you dip below £0 around ${dayLabel(risk.date)}.` : 'Your next 90 days look comfortable.'}\n\nWhere do you want to start?`,
    actions: [
      { label: 'Show me the savings', go: 'savings' },
      { label: 'My cards and points', go: 'cards' },
      { label: 'Can I invest?', ask: 'Can I afford to invest?' },
    ],
  }
}

function catFrom(q: string): Category | null {
  const c = categoryOf(q)
  return c === 'other' ? null : c
}

export function reply(raw: string, s: Snapshot): Reply {
  const q = raw.toLowerCase()

  if (/^(hi|hello|hey)\b/.test(q)) return greeting(s)

  const spend = parseSpend(raw)
  if (spend) return whatIfReply(runWhatIf(s, spend))

  if (/first|where do i (start|begin)|priorit|what should i do|most important|help me/.test(q)) {
    const risk = worstRisk(s)
    const steps: [string, string][] = []
    if (risk.pNeg >= 0.05 && !s.done.has('cushion')) steps.push(['Protect Christmas week', 'Move a £250 cushion'])
    const warn = s.plan.warnings[0]
    if (warn) steps.push([`Clear ${warn.card.name}`, `${money(warn.interestYearly)}/yr interest`])
    s.actions.filter((a) => a.counts && !s.done.has(a.id) && a.yearly > 0).sort((a, b) => b.yearly - a.yearly).slice(0, 3)
      .forEach((a) => steps.push([a.title, `${money(a.yearly)}/yr`]))
    if (!s.done.has('lisa') && s.persona.savingForFirstHome) steps.push(['Then: open a Lifetime ISA', '25% bonus'])
    const first = s.actions.find((a) => a.id === (risk.pNeg >= 0.05 && !s.done.has('cushion') ? 'cushion' : steps[0] ? s.actions.find((x) => x.title === steps[0][0])?.id : ''))
    return {
      text: `Here’s the order I’d go in. Safety first, then the biggest wins for the least effort, then free money.`,
      rows: steps,
      actions: first ? [{ label: `Do it: ${first.title}`, doId: first.id }, { label: 'Open the time machine', go: 'time' }] : [{ label: 'Open savings', go: 'savings' }],
    }
  }

  if (/add .*card|new card|another card/.test(q)) {
    return { text: 'Sure. Tell me the card’s name, its rewards scheme, how many points it has, and whether you pay it off in full each month. I’ll work out what the points are worth and where the card fits.', actions: [{ label: 'Add a card', openAdd: true }] }
  }

  const cat = catFrom(q)
  if (/which card|what card|best card|use for|pay with/.test(q) || (cat && /card/.test(q))) {
    const rows = s.plan.rows.filter((r) => !cat || r.cat === cat)
    const r0 = rows[0]
    const head = cat && r0
      ? r0.best
        ? `For ${CATEGORY_LABEL[cat].toLowerCase()}, use your ${r0.best.name} card. It earns about ${(r0.rate * 100).toFixed(1)}p back per £1. On your usual ${money(r0.monthly)} a month, that’s ${money(r0.yearly)} a year.`
        : 'None of your cards earns anything there. Use whichever you pay off in full.'
      : `Here’s the best card for each kind of spending. Doing this earns about ${money(s.plan.optimisedYearly)} a year, compared with ${money(s.plan.currentYearly)} now.`
    return {
      text: head + (s.plan.warnings.length ? `\n\nFirst, though: you’re carrying a balance on ${s.plan.warnings[0].card.name}. At ${s.plan.warnings[0].card.apr}% that costs about ${money(s.plan.warnings[0].interestYearly)} a year, which is more than any rewards. Clear that first.` : '\n\nThis only works because you pay both cards in full. If that ever changes, rewards stop being worth it.'),
      rows: cat ? undefined : s.plan.rows.map((r) => [CATEGORY_LABEL[r.cat], r.best ? `${r.best.name}, ${money(r.yearly)}/yr` : 'Any card']),
      actions: [{ label: 'Open cards and points', go: 'cards' }],
    }
  }

  if (/point|avios|clubcard|nectar|rewards? worth|membership/.test(q) && !/trip|holiday|travel|fly|take me|go with/.test(q)) {
    const total = s.progs.reduce((a, p) => a + p.best, 0)
    const cash = s.progs.reduce((a, p) => a + p.cash, 0)
    return {
      text: `Your points are worth ${money2(cash)} if you take the easy option, or up to ${money2(total)} if you use them well. The gap is mostly Avios and Clubcard: both are worth more when you spend them on travel or partners than as money off.`,
      rows: s.progs.map((p) => [p.scheme === 'Cashback' ? 'Cashback earned' : `${p.scheme}: ${p.balance.toLocaleString()}`, p.best - p.cash < 0.01 ? money2(p.best) : `${money2(p.cash)} to ${money2(p.best)}`]),
      actions: [{ label: 'See the breakdown', go: 'cards' }, { label: 'Where could they take me?', ask: 'Where could my points take me?' }],
    }
  }

  if (/trip|holiday|vacation|travel|fly|flight|getaway|take me/.test(q)) {
    const t = s.trip
    return {
      text: `You have ${t.avios.toLocaleString()} Avios now. If you finish the Skyward welcome bonus with your normal spending, you’ll have about ${t.byFeb.toLocaleString()} by February. ${t.text}\n\nI’d only book it if you were going to travel anyway, and pay the fees from the trip budget rather than the emergency fund. Prices here are illustrative, so check live availability before you plan around it.`,
      actions: [{ label: 'Open cards and points', go: 'cards' }],
    }
  }

  if (/bonus|sign.?up|welcome/.test(q)) {
    const b = s.plan.bonuses[0]
    if (!b) return { text: 'None of your cards has a welcome bonus running right now.' }
    return {
      text: `${b.card.name} gives ${b.card.bonus!.points.toLocaleString()} points (about ${money(b.valuePounds)}) once you spend ${money(b.card.bonus!.spendRequired)} within ${b.card.bonus!.daysLeft} more days. You’ve spent ${money(b.card.bonus!.spentSoFar)} so far. ${b.onTrack ? 'If you move your everyday spending onto it, you’ll get there without spending a penny more.' : 'You won’t reach it with normal spending, and spending extra to chase it isn’t worth it.'}`,
      actions: [{ label: 'Open cards and points', go: 'cards' }],
    }
  }

  if (/saved|saving this month|money saved|how much.*save/.test(q)) {
    return {
      text: `You’ve saved ${money2(s.savedThisMonth)} this month.${s.potentialYearly > 0 ? ` There’s another ${money(s.potentialYearly)} a year waiting in the Savings tab.` : ''}`,
      rows: s.savedBreakdown.map((b) => [b.label, money2(b.amount)]),
      actions: [{ label: 'See what’s left', go: 'savings' }],
    }
  }

  if (/discount|deal|cheaper|overpay|bill|subscri|cut|reduce/.test(q)) {
    const open = s.actions.filter((a) => a.counts && !s.done.has(a.id) && a.yearly > 0).sort((a, b) => b.yearly - a.yearly).slice(0, 4)
    return {
      text: open.length ? `These are the biggest ones I found in your transactions, largest first:` : 'You’ve already taken everything I found. Nice.',
      rows: open.map((a) => [a.title, `${money(a.yearly)}/yr`]),
      actions: open[0] ? [{ label: `Do it: ${open[0].title}`, doId: open[0].id }, { label: 'See all', go: 'savings' }] : [],
    }
  }

  if (/invest|isa|index|stock|shares|pension|grow|lisa/.test(q)) {
    if (s.safe <= 0) {
      const r = worstRisk(s)
      return {
        text: `Not yet, and here’s why. Your forecast has a ${pct(r.pNeg)} chance of going below £0 around ${dayLabel(r.date)}. Investing now would come out of money you need that week. Two quick fixes, the £250 cushion and the cheaper phone plan, clear it. After that I can set a monthly amount.`,
        actions: [{ label: 'Do it: £250 cushion', doId: 'cushion' }, { label: 'Open the forecast', go: 'time' }],
      }
    }
    return {
      text: `Yes. You can put away ${money(s.safe)} a month and still keep your chance of going below £0 under 10%. Here’s the order I’d use. (This is guidance for people in your situation, not personal advice. Investments can fall as well as rise.)`,
      rows: s.steps.map((st) => [st.when, st.to.map((t) => `${t.name} ${money(t.monthly)}`).join(' + ')]),
      actions: [{ label: 'Open investments', go: 'invest' }],
    }
  }

  if (/emergency|liquid|rainy|cash buffer|savings account/.test(q)) {
    return {
      text: `Your emergency fund covers ${s.monthsCovered.toFixed(1)} months of essentials. The usual target is 3 months (${money(s.emergencyTarget)}). Keep it in easy-access savings, not invested, because you need it to be there on a bad week.`,
      rows: s.pots.map((p) => [p.name, `${money(p.amount)}, ${p.access.toLowerCase()}`]),
      actions: [{ label: 'Open investments', go: 'invest' }],
    }
  }

  if (/short|afford|payday|overdraft|forecast|run out|next month|christmas/.test(q)) {
    const l = lowest(s)
    const r = worstRisk(s)
    return {
      text: `Your lowest point in the next 60 days is likely ${dayLabel(l.date)}, at about ${money(l.p50)}. In a bad case it could be ${money(l.p10)}. ${r.pNeg >= 0.05 ? `There’s a ${pct(r.pNeg)} chance of going below £0 around ${dayLabel(r.date)}, just before payday.` : 'There’s very little chance of going overdrawn.'}`,
      actions: r.pNeg >= 0.05 && !s.done.has('cushion') ? [{ label: 'Do it: £250 cushion', doId: 'cushion' }, { label: 'Open the forecast', go: 'time' }] : [{ label: 'Open the forecast', go: 'time' }],
    }
  }

  return {
    text: 'I can help with what you’ve saved, your cards and points, discounts you’re missing, whether you can invest, and whether you’ll run short. Try one of these:',
    actions: SUGGESTIONS.slice(0, 4).map((x) => ({ label: x, ask: x })),
  }
}

/**
 * What the small model is allowed to know, as short sentences. Numbers come only from the engine.
 * (A 0.6B model follows a dozen plain lines far better than a large JSON blob.)
 */
export function factsFor(s: Snapshot): string[] {
  const r = worstRisk(s)
  const open = s.actions.filter((a) => a.counts && !s.done.has(a.id) && a.yearly > 0).sort((a, b) => b.yearly - a.yearly)
  const pts = s.progs.reduce((a, p) => a + p.best, 0)
  const f = [
    `The person is ${s.persona.name}, ${s.persona.role}.`,
    `Resilience score: ${s.score} out of 100.`,
    `Chance of going below £0 in the next 90 days: ${pct(s.forecast.pAnyNeg)}. The riskiest day is ${dayLabel(r.date)} at ${pct(r.pNeg)}.`,
    `Lowest likely balance in the next 60 days: ${money(lowest(s).p50)} around ${dayLabel(lowest(s).date)}.`,
    `Saved this month: ${money2(s.savedThisMonth)}. Still available: ${money(s.potentialYearly)} a year.`,
    s.safe > 0 ? `Safe to put away each month: ${money(s.safe)}.` : 'Not safe to invest yet: the forecast has too much risk of going below £0.',
    `Emergency fund covers ${s.monthsCovered.toFixed(1)} months of essentials. The target is 3 months.`,
    `Points are worth up to ${money(pts)} if used well.`,
  ]
  open.slice(0, 4).forEach((a) => f.push(`A way to cut costs: ${a.title}, worth ${money(a.yearly)} a year.`))
  const cush = s.actions.find((a) => a.id === 'cushion')
  if (cush && !s.done.has('cushion')) f.push(`A ${money(cush.startBoost ?? 0)} cushion in the current account protects Christmas week.`)
  return f
}

export interface LiveReply { text: string; /** present when the forecast tool ran: the numbers and buttons for the same result */ tool?: Reply }

async function post<T>(url: string, body: unknown, ms: number): Promise<T | null> {
  const ctrl = new AbortController()
  const t = setTimeout(() => ctrl.abort(), ms)
  try {
    const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body), signal: ctrl.signal })
    return r.ok ? ((await r.json()) as T) : null
  } catch {
    return null
  } finally {
    clearTimeout(t)
  }
}

/** Ask the local Qwen3 server. Returns null whenever the built-in reply should be used instead. */
export async function askLive(history: { role: 'user' | 'assistant'; content: string }[], s: Snapshot, base = ''): Promise<LiveReply | null> {
  const question = history[history.length - 1]?.content ?? ''
  const parsed = await post<{ intent?: unknown }>(`${base}/api/intent`, { message: question }, 25_000)
  // the model's reading wins when it is valid; the regex reading is the safety net
  const intent: SpendIntent | null = intentFromModel(parsed?.intent, question) ?? parseSpend(question)

  if (intent) {
    const w = runWhatIf(s, intent)
    const r = await post<{ text: string | null }>(`${base}/api/chat`, { mode: 'spend', messages: history, facts: whatIfFacts(w), verdict: w.verdict, verdictLine: VERDICT_LINE[w.verdict] }, 90_000)
    return typeof r?.text === 'string' ? { text: r.text, tool: whatIfReply(w) } : null
  }
  const r = await post<{ text: string | null }>(`${base}/api/chat`, { mode: 'general', messages: history, facts: factsFor(s) }, 90_000)
  return typeof r?.text === 'string' ? { text: r.text } : null
}
