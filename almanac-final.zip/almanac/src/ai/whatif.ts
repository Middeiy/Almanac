// "Should I spend this?" The tool the chat agent calls.
//
//   user question ──► intent (amount, category, when) ──► this file ──► numbers ──► LLM words them
//
// It re-runs the same Monte Carlo forecast the dashboard shows, with the proposed spend added as a
// one-off, and compares the two futures. The seed is fixed, so the only difference between "before"
// and "after" is the spend itself. The language model never does this arithmetic; it only phrases
// what comes out of here, and every figure it may quote is listed in `whatIfFacts`.
import { simulate, type Forecast } from '../engine/forecast'
import { CATEGORY_LABEL, type Category } from '../engine/cards'
import { addDays, TODAY } from '../lib/dates'
import { dayLabel, money, pct } from '../lib/format'
import type { Snapshot } from '../state'
import type { ChatAction } from './chat'

export type SpendCategory = Category | 'other'
export type Verdict = 'go' | 'careful' | 'hold' | 'essential'

export interface SpendIntent { amount: number; category: SpendCategory; daysFromNow: number }

/** The parts of a Snapshot this tool reads, so it can be tested without the React provider. */
export type WhatIfInput = Pick<Snapshot, 'persona' | 'learned' | 'forecast' | 'overrides' | 'startBoost' | 'actions' | 'done' | 'spend'>

interface Outlook { pAny: number; low: number; lowDate: Date; lowBad: number }

export interface WhatIf {
  intent: SpendIntent
  date: Date
  when: string
  verdict: Verdict
  before: Outlook
  after: Outlook
  /** largest spend on that day that keeps the chance of going below £0 under 10%; 0 if already above */
  safeNow: number
  cushion?: { id: string; amount: number; after: Outlook; safe: number }
  usual?: { monthly: number; weekly: number }
  cutCosts: { id: string; title: string; yearly: number }[]
  /** likely balance for the next 60 days, without and with the spend (drawn in the chat) */
  series: MiniSeries
}

export interface MiniSeries { before: number[]; after: number[]; mark: number; dates: Date[] }

const RISK_LIMIT = 0.1
const MAX_SPEND = 5000
const HORIZON = 90

/* ---------- reading the question without a model (offline fallback, and a check on the model) ---------- */

const TENS: Record<string, number> = { ten: 10, twenty: 20, thirty: 30, forty: 40, fifty: 50, sixty: 60, seventy: 70, eighty: 80, ninety: 90 }
const HUNDREDS: Record<string, number> = { a: 100, one: 100, two: 200, three: 300, four: 400, five: 500 }
const WEEKDAYS = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday']

export function parseAmount(raw: string): number | null {
  const q = raw.toLowerCase()
  const digits = q.match(/£\s?(\d[\d,]*(?:\.\d{1,2})?)/) ?? q.match(/(\d[\d,]*(?:\.\d{1,2})?)\s*(?:pounds?|quid|gbp|sterling)\b/)
  if (digits) return parseFloat(digits[1].replace(/,/g, ''))
  const h = q.match(/\b(a|one|two|three|four|five)\s+hundred\s*(?:pounds?|quid)\b/)
  if (h) return HUNDREDS[h[1]]
  const t = q.match(/\b(ten|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety)\s*(?:pounds?|quid)\b/)
  return t ? TENS[t[1]] : null
}

export function parseWhen(raw: string): number {
  const q = raw.toLowerCase()
  if (/tomorrow/.test(q)) return 1
  if (/next week/.test(q)) return 7
  const n = q.match(/in (\d{1,2}) days?/)
  if (n) return Math.min(HORIZON - 1, parseInt(n[1], 10))
  const w = WEEKDAYS.findIndex((d) => q.includes(d))
  if (w >= 0) return (w - TODAY.getDay() + 7) % 7 || 7
  return 0
}

export function categoryOf(q: string): SpendCategory {
  if (/grocer|food shop|supermarket|tesco|sainsbury/.test(q)) return 'groceries'
  if (/travel|train|commut|flight|rail/.test(q)) return 'travel'
  if (/\beat\b|restaurant|takeaway|dining|coffee|deliveroo|night out|out tonight|\bpub\b|drinks|dinner|\bbar\b/.test(q)) return 'dining'
  if (/shop|amazon|cloth|trainers|shoes/.test(q)) return 'shopping'
  if (/bill|subscription|netflix|phone/.test(q)) return 'bills'
  return 'other'
}

const SPEND_CUE = /spend|buy|\bget\b|pay|order|treat|splash|afford|worth|should i|can i|go out|out tonight|night out|dinner|drinks|groceries|shop/
const NOT_SPENDING = /invest|\bisa\b|lisa|pension|saving|\bsave\b|transfer|deposit/

/** A spend question with an amount in it. Returns null for everything else, so other chats are untouched. */
export function parseSpend(raw: string): SpendIntent | null {
  const q = raw.toLowerCase()
  const amount = parseAmount(q)
  if (amount === null || amount <= 0 || amount > MAX_SPEND) return null
  if (!SPEND_CUE.test(q) || NOT_SPENDING.test(q)) return null
  return { amount, category: categoryOf(q), daysFromNow: parseWhen(q) }
}

/** Accepts the model's JSON only if it makes sense; anything odd returns null so the regex reading is used. */
export function intentFromModel(x: unknown, message: string): SpendIntent | null {
  if (!x || typeof x !== 'object') return null
  const o = x as Record<string, unknown>
  if (o.intent !== 'spend_check' || typeof o.amount !== 'number' || !(o.amount > 0 && o.amount <= MAX_SPEND)) return null
  const cats = ['groceries', 'travel', 'dining', 'shopping', 'bills', 'other']
  const category = typeof o.category === 'string' && cats.includes(o.category) ? (o.category as SpendCategory) : categoryOf(message.toLowerCase())
  const d = typeof o.days_from_now === 'number' && Number.isInteger(o.days_from_now) ? o.days_from_now : parseWhen(message)
  return { amount: o.amount, category, daysFromNow: Math.min(HORIZON - 1, Math.max(0, d)) }
}

/* ---------- the maths ---------- */

const RELEVANT: Record<SpendCategory, string[]> = {
  groceries: ['clubcard', 'nectar', 'card_routing'],
  dining: ['nhs_discounts', 'card_routing'],
  shopping: ['nhs_discounts', 'card_routing'],
  bills: ['sim_only', 'broadband', 'rotate_streaming'],
  travel: ['card_routing'],
  other: [],
}
const ESSENTIAL: SpendCategory[] = ['groceries', 'bills']

function outlook(f: Forecast): Outlook {
  const low = f.days.reduce((w, d) => (d.p50 < w.p50 ? d : w))
  return { pAny: f.pAnyNeg, low: low.p50, lowDate: low.date, lowBad: f.days.reduce((m, d) => Math.min(m, d.p10), Infinity) }
}

export function runWhatIf(s: WhatIfInput, intent: SpendIntent): WhatIf {
  const date = addDays(TODAY, intent.daysFromNow)
  const run = (amount: number, boost = 0) => simulate(s.persona, s.learned, {
    moves: new Set(), monthlySaving: 0, overrides: s.overrides, startBoost: s.startBoost + boost,
    shocks: amount > 0 ? { oneOffs: [{ date, amount: -amount }] } : undefined,
  })
  // largest spend that keeps the chance of ever going below £0 under 10%, to the nearest £5
  const safeSpend = (boost = 0) => {
    if (run(0, boost).pAnyNeg > RISK_LIMIT) return 0
    let lo = 0
    let hi = 500
    while (hi - lo > 5) {
      const mid = Math.round((lo + hi) / 2 / 5) * 5
      if (run(mid, boost).pAnyNeg <= RISK_LIMIT) lo = mid
      else hi = mid
    }
    return lo
  }

  const before = outlook(s.forecast)
  const afterRun = run(intent.amount)
  const after = outlook(afterRun)
  const series: MiniSeries = {
    before: s.forecast.days.slice(0, 60).map((d) => d.p50),
    after: afterRun.days.slice(0, 60).map((d) => d.p50),
    mark: intent.daysFromNow,
    dates: s.forecast.days.slice(0, 60).map((d) => d.date),
  }
  const delta = after.pAny - before.pAny
  const essential = ESSENTIAL.includes(intent.category)
  const verdict: Verdict = essential ? 'essential'
    : after.pAny < RISK_LIMIT || delta < 0.01 ? 'go'
    : after.low < 0 || delta >= 0.15 || (after.pAny >= 0.25 && delta >= 0.05) ? 'hold'
    : 'careful'

  const cush = s.actions.find((a) => a.id === 'cushion')
  const cushion = cush && !s.done.has(cush.id) && cush.startBoost && verdict !== 'go'
    ? { id: cush.id, amount: cush.startBoost, after: outlook(run(intent.amount, cush.startBoost)), safe: safeSpend(cush.startBoost) }
    : undefined

  const open = s.actions.filter((a) => a.counts && !s.done.has(a.id) && a.yearly > 0)
  const pick = [
    ...RELEVANT[intent.category].map((id) => open.find((a) => a.id === id)),
    ...[...open].sort((a, b) => b.yearly - a.yearly),
  ].filter((a, i, all): a is NonNullable<typeof a> => !!a && all.indexOf(a) === i).slice(0, 2)

  const monthly = intent.category === 'other' ? 0 : s.spend[intent.category]
  return {
    intent, date, verdict, before, after, cushion,
    when: intent.daysFromNow === 0 ? 'tonight' : intent.daysFromNow === 1 ? 'tomorrow' : `on ${dayLabel(date)}`,
    safeNow: verdict === 'go' ? 0 : safeSpend(),
    usual: essential && monthly > 0 ? { monthly, weekly: monthly / 4.33 } : undefined,
    cutCosts: pick.map((a) => ({ id: a.id, title: a.title, yearly: Math.round(a.yearly) })),
    series,
  }
}

/* ---------- handing the result to the language model ---------- */

export const VERDICT_LINE: Record<Verdict, string> = {
  go: 'GO AHEAD. This spend barely changes the forecast.',
  careful: 'GO CAREFULLY. It adds real risk, so suggest the safer option below.',
  hold: 'HOLD OFF. Say plainly that they should not do this now.',
  essential: 'IT IS A NEED. Do not tell them to skip it. Say buy it, and point to ways to spend less.',
}

/** Every number the model is allowed to quote, as plain sentences. Small models copy these reliably. */
export function whatIfFacts(w: WhatIf): string[] {
  const { intent: i, before: b, after: a } = w
  const f: string[] = [
    `The person is asking about spending ${money(i.amount)} on ${i.category === 'other' ? 'something' : CATEGORY_LABEL[i.category].toLowerCase()} ${w.when}.`,
    `Without it: ${pct(b.pAny)} chance of going below £0 at some point in the next 90 days. Lowest likely balance ${money(b.low)} around ${dayLabel(b.lowDate)}.`,
    `With it: ${pct(a.pAny)} chance of going below £0. Lowest likely balance ${money(a.low)} around ${dayLabel(a.lowDate)}.`,
  ]
  if (w.usual) {
    const ratio = i.amount > w.usual.weekly * 1.2 ? 'more than a normal weekly shop' : 'about a normal weekly shop'
    f.push(`Their usual spend here is about ${money(w.usual.monthly)} a month, about ${money(w.usual.weekly)} a week, so ${money(i.amount)} is ${ratio}.`)
  }
  if (w.verdict !== 'go') {
    f.push(w.safeNow > 0
      ? `The most they could spend ${w.when} and stay under a 10% chance of going below £0 is ${money(w.safeNow)}.`
      : `They are already above a 10% chance of going below £0, so no extra spending is safe right now.`)
  }
  if (w.cushion) {
    f.push(`Moving a ${money(w.cushion.amount)} cushion into the current account first would cut the chance of going below £0 to ${pct(w.cushion.after.pAny)} even after this spend, and then up to ${money(w.cushion.safe)} could be spent safely.`)
  }
  w.cutCosts.forEach((c) => f.push(`A way to cut costs: ${c.title}, worth ${money(c.yearly)} a year.`))
  return f
}

/** The same result written without a model: used when the AI server is off, slow, or fails a check. */
export function whatIfReply(w: WhatIf): { text: string; rows: [string, string][]; actions: ChatAction[]; chart: MiniSeries } {
  const { intent: i, before: b, after: a } = w
  const amt = money(i.amount)
  const move = `Your chance of going below £0 in the next 90 days goes from ${pct(b.pAny)} to ${pct(a.pAny)}, and your lowest likely balance (around ${dayLabel(a.lowDate)}) goes from ${money(b.low)} to ${money(a.low)}.`
  const cush = w.cushion
    ? ` If you move the ${money(w.cushion.amount)} cushion first, the chance drops to ${pct(w.cushion.after.pAny)} even after spending it, and you could spend up to ${money(w.cushion.safe)} safely.`
    : w.safeNow > 0 ? ` Up to ${money(w.safeNow)} ${w.when} keeps you under a 10% chance of going below £0.` : ''
  const cut = w.cutCosts[0] ? `\n\nTo free up money for things like this: ${w.cutCosts[0].title}, worth about ${money(w.cutCosts[0].yearly)} a year.` : ''

  const head: Record<Verdict, string> = {
    hold: `I’d hold off on ${amt} ${w.when}. ${move}`,
    careful: `You can, but be careful. ${amt} ${w.when} adds real risk. ${move}`,
    go: `Yes, that’s fine. ${amt} ${w.when} barely changes your forecast. ${move}`,
    essential: `Food is a need, so I wouldn’t skip it. ${w.usual ? `You usually spend about ${money(w.usual.weekly)} a week here, so ${amt} is ${i.amount > w.usual.weekly * 1.2 ? 'more than' : 'about'} a normal shop. ` : ''}${move}`,
  }
  const actions: ChatAction[] = []
  if (w.cushion) actions.push({ label: `Do it: ${money(w.cushion.amount)} cushion`, doId: w.cushion.id })
  if (w.cutCosts[0]) actions.push({ label: `Do it: ${w.cutCosts[0].title}`, doId: w.cutCosts[0].id })
  actions.push({ label: 'Open the forecast', go: 'time' })
  return {
    text: head[w.verdict] + cush + cut,
    rows: [
      ['Chance of going below £0, now', pct(b.pAny)],
      [`…if you spend ${amt}`, pct(a.pAny)],
      ['Lowest likely balance', `${money(b.low)} → ${money(a.low)}`],
    ],
    actions,
    chart: w.series,
  }
}
