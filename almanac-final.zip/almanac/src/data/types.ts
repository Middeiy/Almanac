// Shape follows the UK Open Banking Account & Transaction API (v3.1 OBTransaction6),
// which NatWest exposes through its Bank of APIs. Swapping synthetic data for the
// sandbox means replacing `raw` — nothing downstream changes.
export interface OBTransaction {
  AccountId: string
  TransactionId: string
  BookingDateTime: string
  Amount: { Amount: string; Currency: 'GBP' }
  CreditDebitIndicator: 'Credit' | 'Debit'
  Status: 'Booked'
  TransactionInformation: string
  MerchantDetails?: { MerchantName: string; MerchantCategoryCode?: string }
}

/** Normalised view the engines work on. amount < 0 is money out. */
export interface Txn {
  id: string
  date: Date
  amount: number
  merchant: string
  info: string
  mcc?: string
}

export interface PointsBalance {
  scheme: string
  balance: number
}

export interface Persona {
  id: string
  name: string
  age: number
  role: string
  city: string
  blurb: string
  startBalance: number
  /** Monthly essentials (rent, bills, food, travel), used to size the emergency fund. */
  essentials: number
  accounts: { current: number; easyAccess: number; lisa: number; investments: number }
  savingForFirstHome: boolean
  nhsWorker: boolean
  onUC: boolean
  livesAlone: boolean
  uc?: { maxAward: number; workAllowance: number; payDay: number; apStartDay: number }
  priors: { christmasSpend: number; winterEnergyUplift: number; busySeasonEarnings: number }
  points: PointsBalance[]
  history: Txn[]
  raw: OBTransaction[]
}
