import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { SAM } from './data/personas'
import type { Persona } from './data/types'
import { learn, type Learned } from './engine/learn'
import { safeToSave, simulate, type Forecast, type Override } from './engine/forecast'
import { DEFAULT_CARDS, planCards, programs, spendByCategory, tripIdea, type Card, type CardPlan, type Category, type Program } from './engine/cards'
import { actionsFor, type Action } from './engine/savings'
import { allocate, liquidity, type Pot, type Step } from './engine/invest'
import { briefing, resilience, type ResiliencePart } from './engine/insights'
import { nudgesFor, type Nudge } from './engine/nudges'
import type { ChatAction } from './ai/chat'
import type { MiniSeries } from './ai/whatif'

export interface Msg { id: number; role: 'user' | 'assistant'; text: string; rows?: [string, string][]; actions?: ChatAction[]; live?: boolean; chart?: MiniSeries }

export type View = 'overview' | 'time' | 'savings' | 'cards' | 'invest' | 'trust' | 'how'

export interface Snapshot {
  persona: Persona
  learned: Learned
  cards: Card[]
  spend: Record<Category, number>
  plan: CardPlan
  progs: Program[]
  trip: ReturnType<typeof tripIdea>
  actions: Action[]
  done: Set<string>
  forecast: Forecast
  baseline: Forecast
  safe: number
  planSafe: number
  steps: Step[]
  pots: Pot[]
  monthsCovered: number
  emergencyTarget: number
  savedThisMonth: number
  savedBreakdown: { label: string; amount: number }[]
  potentialYearly: number
  doneYearly: number
  score: number
  scoreBefore: number
  scoreParts: ResiliencePart[]
  brief: string[]
  overrides: Override[]
  startBoost: number
  nudges: Nudge[]
}

export interface AiStatus { state: 'checking' | 'online' | 'offline'; model?: string; device?: string }

interface Toast { text: string; undo?: () => void }

interface Ctx extends Snapshot {
  view: View
  setView: (v: View) => void
  toggle: (id: string) => void
  complete: (id: string) => void
  addCard: (c: Card) => void
  removeCard: (id: string) => void
  addOpen: boolean
  setAddOpen: (b: boolean) => void
  toast: Toast | null
  flash: (s: string, undo?: () => void) => void
  messages: Msg[]
  push: (m: Omit<Msg, 'id'>) => void
  say: (text: string) => void
  onboarded: boolean
  finishOnboarding: () => void
  simple: boolean
  setSimple: (b: boolean) => void
  large: boolean
  setLarge: (b: boolean) => void
  speak: boolean
  setSpeak: (b: boolean) => void
  paletteOpen: boolean
  setPaletteOpen: (b: boolean) => void
  chatDraft: string | null
  askChat: (q: string) => void
  clearChatDraft: () => void
  resetDemo: () => void
  exportData: () => string
  ai: AiStatus
  scriptFor: string | null
  setScriptFor: (id: string | null) => void
  notes: boolean
  setNotes: (b: boolean) => void
}

const C = createContext<Ctx | null>(null)
const learned = learn(SAM.history)
const spend = spendByCategory(SAM)
const KEY = 'almanac-demo-v2'

interface Saved { done: string[]; userCards: Card[]; onboarded: boolean; simple: boolean; large: boolean; speak: boolean }
function load(): Partial<Saved> {
  try { return JSON.parse(localStorage.getItem(KEY) ?? '{}') } catch { return {} }
}

export function Provider({ children }: { children: ReactNode }) {
  const saved = useMemo(load, [])
  const [view, setView] = useState<View>('overview')
  const [userCards, setUserCards] = useState<Card[]>(saved.userCards ?? [])
  const [doneList, setDoneList] = useState<string[]>(saved.done ?? [])
  const [addOpen, setAddOpen] = useState(false)
  const [toast, setToast] = useState<Toast | null>(null)
  const [messages, setMessages] = useState<Msg[]>([])
  const [onboarded, setOnboarded] = useState(saved.onboarded ?? false)
  const [simple, setSimple] = useState(saved.simple ?? false)
  const [large, setLarge] = useState(saved.large ?? false)
  const [speak, setSpeak] = useState(saved.speak ?? false)
  const [paletteOpen, setPaletteOpen] = useState(false)
  const [chatDraft, setChatDraft] = useState<string | null>(null)
  const [ai, setAi] = useState<AiStatus>({ state: 'checking' })
  const [scriptFor, setScriptFor] = useState<string | null>(null)
  const [notes, setNotes] = useState(false)

  // Is the local Qwen3 server running? (Vite proxies /api to it.)
  useEffect(() => {
    const ctrl = new AbortController()
    const t = setTimeout(() => ctrl.abort(), 3000)
    fetch('/api/health', { signal: ctrl.signal })
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((j) => setAi({ state: 'online', model: j.model, device: j.device }))
      .catch(() => setAi({ state: 'offline' }))
      .finally(() => clearTimeout(t))
  }, [])

  useEffect(() => {
    try { localStorage.setItem(KEY, JSON.stringify({ done: doneList, userCards, onboarded, simple, large, speak })) } catch { /* storage unavailable */ }
  }, [doneList, userCards, onboarded, simple, large, speak])

  const cards = useMemo(() => [...DEFAULT_CARDS, ...userCards], [userCards])
  const done = useMemo(() => new Set(doneList), [doneList])
  const persona = SAM

  const plan = useMemo(() => planCards(cards, spend), [cards])
  const progs = useMemo(() => programs(persona, cards), [persona, cards])
  const trip = useMemo(() => tripIdea(progs, plan), [progs, plan])
  const actions = useMemo(() => actionsFor(persona, learned, plan.gain), [persona, plan.gain])

  const effects = (ids: Set<string>) => {
    const ov: Override[] = []
    let boost = 0
    actions.filter((a) => ids.has(a.id)).forEach((a) => { ov.push(...(a.overrides ?? [])); boost += a.startBoost ?? 0 })
    return { overrides: ov, startBoost: boost }
  }
  const { overrides, startBoost } = useMemo(() => effects(done), [actions, done]) // eslint-disable-line

  const baseline = useMemo(() => simulate(persona, learned, { moves: new Set(), monthlySaving: 0 }), [persona])
  const forecast = useMemo(() => simulate(persona, learned, { moves: new Set(), monthlySaving: 0, overrides, startBoost }), [persona, overrides, startBoost])
  const safe = useMemo(() => safeToSave(persona, learned, new Set(), 0.1, { overrides, startBoost }), [persona, overrides, startBoost])
  // What the plan could free up if every action were taken (for the "two futures" view)
  const planSafe = useMemo(() => {
    const all = effects(new Set(actions.map((a) => a.id)))
    const offForecast = actions.filter((a) => a.counts && !a.overrides).reduce((s, a) => s + a.yearly / 12, 0)
    return safeToSave(persona, learned, new Set(), 0.1, all) + Math.round(offForecast)
  }, [persona, actions]) // eslint-disable-line

  const cardDebt = cards.reduce((s, c) => s + (c.paysInFull ? 0 : c.balance), 0)
  const liq = liquidity(persona, done.has('cushion'), cardDebt)
  const emergencyNow = liq.pots[1].amount
  const steps = useMemo(() => allocate(persona, safe, emergencyNow), [persona, safe, emergencyNow])

  const club = learned.clubcardSavedThisMonth
  const savedBreakdown = [
    { label: 'Clubcard Prices', amount: club },
    ...actions.filter((a) => done.has(a.id) && a.counts && a.yearly > 0).map((a) => ({ label: a.title, amount: a.yearly / 12 })),
  ]
  const savedThisMonth = savedBreakdown.reduce((s, b) => s + b.amount, 0)
  const potentialYearly = actions.filter((a) => a.counts && !done.has(a.id)).reduce((s, a) => s + a.yearly, 0)
  const doneYearly = actions.filter((a) => a.counts && done.has(a.id)).reduce((s, a) => s + a.yearly, 0)

  const r = resilience({ pAnyNeg: forecast.pAnyNeg, monthsCovered: liq.monthsCovered, cardDebt, safe, income: learned.monthlyIncome, doneYearly, potentialYearly })
  const r0 = useMemo(() => {
    const all = actions.filter((a) => a.counts).reduce((s, a) => s + a.yearly, 0)
    return resilience({ pAnyNeg: baseline.pAnyNeg, monthsCovered: persona.accounts.easyAccess / persona.essentials, cardDebt: 0, safe: 0, income: learned.monthlyIncome, doneYearly: 0, potentialYearly: all })
  }, [actions, baseline, persona])
  const brief = briefing({ forecast, actions, done, progs, name: persona.name })
  const nudges = useMemo(() => nudgesFor({ forecast, learned, actions, done, plan, progs, safe }), [forecast, actions, done, plan, progs, safe])

  const push = (m: Omit<Msg, 'id'>) => setMessages((ms) => [...ms, { ...m, id: Date.now() + Math.random() }])
  const flash = (text: string, undo?: () => void) => { setToast({ text, undo }); window.setTimeout(() => setToast((t) => (t?.text === text ? null : t)), 4000) }
  const toggle = (id: string) => setDoneList((d) => (d.includes(id) ? d.filter((x) => x !== id) : [...d, id]))

  const value: Ctx = {
    persona, learned, cards, spend, plan, progs, trip, actions, done, forecast, baseline, safe, planSafe, steps,
    pots: liq.pots, monthsCovered: liq.monthsCovered, emergencyTarget: liq.target,
    savedThisMonth, savedBreakdown, potentialYearly, doneYearly,
    score: r.score, scoreBefore: r0.score, scoreParts: r.parts, brief, overrides, startBoost, nudges,
    ai, scriptFor, setScriptFor, notes, setNotes,
    view, setView: (v) => { setView(v); setPaletteOpen(false) },
    toggle,
    complete: (id) => {
      if (done.has(id)) return
      const a = actions.find((x) => x.id === id)
      toggle(id)
      flash(a && a.yearly > 0 ? `Done. ${Math.round(a.yearly).toLocaleString('en-GB', { style: 'currency', currency: 'GBP', maximumFractionDigits: 0 })} a year saved` : 'Done. Forecast updated', () => { setDoneList((d) => d.filter((x) => x !== id)); setToast(null) })
    },
    addCard: (c) => setUserCards((cs) => [...cs, c]),
    removeCard: (id) => setUserCards((cs) => cs.filter((c) => c.id !== id)),
    addOpen, setAddOpen,
    toast, flash,
    messages, push,
    say: (text) => push({ role: 'assistant', text }),
    onboarded, finishOnboarding: () => setOnboarded(true),
    simple, setSimple, large, setLarge, speak, setSpeak,
    paletteOpen, setPaletteOpen,
    chatDraft, askChat: (q) => { setChatDraft(q); setPaletteOpen(false) }, clearChatDraft: () => setChatDraft(null),
    resetDemo: () => {
      try { localStorage.removeItem(KEY) } catch { /* ignore */ }
      setDoneList([]); setUserCards([]); setMessages([]); setOnboarded(false); setView('overview'); setSimple(false); setLarge(false)
    },
    exportData: () => JSON.stringify({
      exported: new Date().toISOString(),
      person: { name: persona.name, role: persona.role },
      accounts: persona.accounts,
      cards: cards.map(({ tone: _t, ...c }) => c),
      actionsDone: doneList,
      transactions: persona.raw,
    }, null, 2),
  }
  return <C.Provider value={value}>{children}</C.Provider>
}

export function useApp() {
  const c = useContext(C)
  if (!c) throw new Error('useApp outside Provider')
  return c
}
