import { mulberry32, normal } from '../lib/rng'
import type { Persona } from '../data/types'

export interface Pot { name: string; amount: number; access: string; role: string }

/** Where the money sits today, ordered from most to least liquid. */
export function liquidity(p: Persona, cushionMoved: boolean, cardDebt: number): { pots: Pot[]; monthsCovered: number; target: number } {
  const move = cushionMoved ? 250 : 0
  const pots: Pot[] = [
    { name: 'Current account', amount: p.accounts.current + move, access: 'Instant', role: 'Bills and spending' },
    { name: 'Easy-access savings', amount: p.accounts.easyAccess - move, access: 'Same day', role: 'Emergency fund' },
    { name: 'Lifetime ISA', amount: p.accounts.lisa, access: 'For a first home or at 60', role: 'House deposit' },
    { name: 'Investments (ISA)', amount: p.accounts.investments, access: 'A few days, value moves', role: 'Long-term growth' },
  ]
  void cardDebt
  const target = p.essentials * 3
  return { pots, monthsCovered: (p.accounts.easyAccess - move) / p.essentials, target }
}

export interface Step { when: string; to: { name: string; monthly: number; bonusRate: number }[]; why: string }

/** The order of operations a wealth manager would use, applied to the monthly amount that's safe. */
export function allocate(p: Persona, safe: number, emergencyNow: number): Step[] {
  if (safe <= 0) return []
  const oneMonth = p.essentials
  const threeMonths = p.essentials * 3
  const steps: Step[] = []
  let fund = emergencyNow
  let month = 0
  const label = (m: number) => new Date(2026, 11 + m, 1).toLocaleDateString('en-GB', { month: 'long', year: 'numeric' })
  if (fund < oneMonth) {
    const n = Math.ceil((oneMonth - fund) / safe)
    steps.push({ when: `${label(0)} to ${label(n - 1)}`, to: [{ name: 'Emergency fund', monthly: safe, bonusRate: 0 }], why: `Get to one month of essentials (£${oneMonth.toLocaleString()}) first. An emergency fund stops one bad month becoming debt.` })
    fund += n * safe
    month += n
  }
  if (p.savingForFirstHome) {
    const lisa = Math.min(333, Math.round(safe / 2 / 5) * 5)
    steps.push({ when: `From ${label(month)}`, to: [
      { name: 'Lifetime ISA (global index fund)', monthly: lisa, bonusRate: 0.25 },
      { name: 'Emergency fund', monthly: safe - lisa, bonusRate: 0 },
    ], why: `Take the free 25% while you build towards three months of essentials (£${threeMonths.toLocaleString()}).` })
  } else {
    steps.push({ when: `From ${label(month)}`, to: [{ name: 'Global index fund (Stocks & Shares ISA)', monthly: safe, bonusRate: 0 }], why: 'Low-cost, thousands of companies, tax-free inside an ISA.' })
  }
  return steps
}

/** Monte Carlo of a monthly contribution into a global index fund (real terms). */
export function project(monthly: number, years = 10, bonusRate = 0, seed = 3) {
  const N = 600
  const months = years * 12
  const mu = 0.05 / 12
  const sigma = 0.15 / Math.sqrt(12)
  const rng = mulberry32(seed)
  const paths: number[][] = []
  for (let k = 0; k < N; k++) {
    let v = 0
    const row: number[] = []
    for (let m = 0; m < months; m++) {
      v = (v + monthly * (1 + bonusRate)) * Math.exp(mu - 0.5 * sigma * sigma + sigma * normal(rng))
      if ((m + 1) % 12 === 0) row.push(v)
    }
    paths.push(row)
  }
  return Array.from({ length: years }, (_, y) => {
    const s = paths.map((r) => r[y]).sort((a, b) => a - b)
    return { year: y + 1, p10: s[Math.floor(N * 0.1)], p50: s[Math.floor(N * 0.5)], p90: s[Math.floor(N * 0.9)], paidIn: monthly * 12 * (y + 1) }
  })
}
