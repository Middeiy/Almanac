// Savings & discounts: rules that read the transactions and produce ranked,
// evidenced actions. Deterministic on purpose — the chat explains these, it never invents them.
import type { Persona } from '../data/types'
import type { Learned } from './learn'
import type { Override } from './forecast'

export type Kind = 'Free money' | 'Bills' | 'Subscriptions' | 'Shopping' | 'Work perks' | 'Cards' | 'Cash flow'

export interface Action {
  id: string
  kind: Kind
  title: string
  detail: string
  yearly: number
  effort: string
  evidence: string[]
  /** effect on the cash-flow forecast, if any */
  overrides?: Override[]
  startBoost?: number
  counts: boolean
  source?: { label: string; url: string }
  illustrative?: boolean
  /** "Do it for me": exactly what to say or tap, ready to copy */
  script?: { how: string; lines: string[] }
}

const ids = (p: Persona, re: RegExp) => p.history.filter((t) => re.test(t.merchant)).map((t) => t.id)
const DEC = new Date(2026, 11, 1)

export function actionsFor(p: Persona, L: Learned, cardGain: number): Action[] {
  const a: Action[] = []
  const rec = (re: RegExp) => L.recurring.find((r) => re.test(r.merchant))

  const ee = rec(/^EE$/)
  if (ee) a.push({
    id: 'sim_only', kind: 'Bills', counts: true,
    script: { how: 'Two texts and one order. You keep your number.', lines: [
      'Text PAC to 65075 from your phone. You’ll get a free switching code by text straight away.',
      'Pick a SIM-only plan with about the same data you use now (check Settings → Mobile data).',
      'When you order, give the new network your PAC code. They move your number, usually the next working day.',
      'Your old contract ends automatically. Your last bill may include a few days’ charge.',
    ] },
    title: 'Move your phone to a SIM-only plan',
    detail: `You pay £${Math.abs(ee.median).toFixed(0)} a month to EE and the contract looks paid off (same amount for 3+ months, no handset payments). SIM-only plans with similar data start around £10.`,
    yearly: (Math.abs(ee.median) - 10) * 12, effort: '10 minutes, keep your number',
    evidence: ee.txnIds, overrides: [{ match: (r) => r.merchant === 'EE', amount: -10, from: DEC }],
    illustrative: true,
  })
  const bt = rec(/BT Broadband/)
  if (bt) a.push({
    id: 'broadband', kind: 'Bills', counts: true,
    script: { how: 'A 5-minute call. Read this out.', lines: [
      '“Hi, I’d like to talk about my bill. I’m out of contract and paying £34 a month.”',
      '“New customers are getting the same speed for about £25. Can you offer me a new contract at that price?”',
      'If they say no: “Then I’d like to leave. Can you put me through to the team that handles cancellations?”',
      '“Before I go, is there anything you can do on the price?” Most people get an offer at this point.',
      'If you do switch, you only need to contact the new provider. They arrange the move for you.',
    ] },
    title: 'Re-contract your broadband',
    detail: `£${Math.abs(bt.median).toFixed(0)} a month is an out-of-contract price. Calling to re-contract, or switching, usually gets the same speed for about £25.`,
    yearly: (Math.abs(bt.median) - 25) * 12, effort: 'One phone call',
    evidence: bt.txnIds, overrides: [{ match: (r) => r.merchant === 'BT Broadband', amount: -25, from: DEC }],
    illustrative: true,
  })
  const subs = L.recurring.filter((r) => r.mcc === '5815')
  const disney = rec(/Disney/)
  if (disney && subs.length >= 3) a.push({
    id: 'rotate_streaming', kind: 'Subscriptions', counts: true,
    script: { how: 'Two minutes in the app.', lines: [
      'Open Disney+ → Profile → Account → Subscription → Cancel subscription.',
      'You keep watching until the end of the month you’ve paid for.',
      'When there’s a show you want, resubscribe for a month, binge it, and cancel again.',
    ] },
    title: 'Rotate your streaming instead of stacking it',
    detail: `You pay for ${subs.map((s) => s.merchant).join(', ')} every month. Keeping one video service at a time and switching when you've finished a show saves about £${Math.abs(disney.median).toFixed(2)} a month.`,
    yearly: Math.abs(disney.median) * 12, effort: '2 minutes',
    evidence: subs.flatMap((s) => s.txnIds), overrides: [{ match: (r) => r.merchant === 'Disney+', amount: 0, from: new Date(2026, 10, 9) }],
  })
  if (p.nhsWorker) {
    const eat = p.history.filter((t) => ['5814', '5812', '5311', '7997'].includes(t.mcc ?? '')).reduce((s, t) => s - t.amount, 0) / 3
    a.push({
      id: 'nhs_discounts', kind: 'Work perks', counts: true,
    script: { how: 'Ten minutes, once.', lines: [
      'Sign up to an NHS staff discount scheme (for example Health Service Discounts or Blue Light Card) with your NHS email.',
      'Add the digital card to your phone wallet so it’s there at the till.',
      'Check it before eating out, gym renewals and big shops.',
    ] },
      title: 'Use NHS staff discounts',
      detail: `As NHS staff you can get discount schemes for food, shopping and gyms. You spend about £${Math.round(eat)} a month in places that commonly take them. A cautious 5% back is the estimate.`,
      yearly: Math.round(eat * 12 * 0.05), effort: 'Sign up with your NHS email',
      evidence: ids(p, /Pret|Greggs|Costa|Deliveroo|PureGym|Boots/).slice(-6), illustrative: true,
    })
  }
  if (L.sainsburysSpendMonthly > 0) a.push({
    id: 'nectar', kind: 'Shopping', counts: true,
    script: { how: 'Five minutes, once.', lines: [
      'Download the Nectar app and sign in or create an account.',
      'Add your Nectar card to Apple Wallet or Google Wallet.',
      'Scan it at the till on Saturdays. Nectar Prices come off automatically.',
    ] },
    title: 'Scan Nectar at Sainsbury’s',
    detail: `You spend about £${Math.round(L.sainsburysSpendMonthly)} a month at Sainsbury’s and none of it shows Nectar Prices. 3% is a cautious estimate of what member prices save.`,
    yearly: Math.round(L.sainsburysSpendMonthly * 0.03 * 12), effort: 'Add Nectar to your phone',
    evidence: ids(p, /Sainsbury/).slice(-6), illustrative: true,
  })
  const tescoMissed = p.history.filter((t) => t.merchant === 'Tesco' && !/CLUBCARD/.test(t.info))
  if (tescoMissed.length) a.push({
    id: 'clubcard', kind: 'Shopping', counts: true,
    script: { how: 'One minute, once.', lines: [
      'Open the Tesco app → Clubcard → Add to wallet.',
      'Scan it at every Tesco, including Express. Clubcard Prices only apply when you scan.',
    ] },
    title: 'Scan Clubcard on every Tesco shop',
    detail: `${tescoMissed.length} of your Tesco shops in the last 3 months missed Clubcard Prices. When you did scan, you saved about £1.60 a time.`,
    yearly: Math.round((tescoMissed.length / 3) * 1.6 * 12), effort: 'Add it to your phone wallet',
    evidence: tescoMissed.map((t) => t.id).slice(-6),
  })
  if (cardGain > 1) a.push({
    id: 'card_routing', kind: 'Cards', counts: true,
    script: { how: 'Set it once in your phone wallet.', lines: [
      'Make Skyward Avios your default card in Apple Wallet or Google Wallet. It earns the most on almost everything you buy.',
      'Set both cards to pay the full balance by direct debit, so rewards never turn into interest.',
      'Keep Everyday Cashback as a backup only.',
    ] },
    title: 'Use the right card for each kind of spending',
    detail: 'Your spending earns 0.5% today. Putting each category on your best card, and paying both cards in full, earns more for the same spending.',
    yearly: cardGain, effort: 'Change your default card in your phone wallet',
    evidence: ids(p, /Cashback Card/),
  })
  if (p.savingForFirstHome) a.push({
    id: 'lisa', kind: 'Free money', counts: true,
    script: { how: 'A checklist before you open one.', lines: [
      'You must be 18 to 39 to open one, and can pay in until you’re 50.',
      'Up to £4,000 a year, which counts towards your £20,000 ISA allowance.',
      'Choose a cash or stocks and shares Lifetime ISA. Almanac’s plan assumes a low-cost global index fund. Capital at risk.',
      'Only put in money you won’t need for an emergency: withdrawals for anything except a first home up to £450,000 or after 60 cost 25%.',
    ] },
    title: 'Open a Lifetime ISA',
    detail: `You’re ${p.age} and saving for a first home. The government adds 25% to what you pay in, up to £1,000 a year. Use it for a first home up to £450,000 (or after 60). Taking money out for anything else costs 25%, so only put in money you won’t need for an emergency. New accounts close in April 2029 when the First Time Buyer ISA replaces it, and existing ones carry on.`,
    yearly: 0, effort: '10 minutes',
    evidence: [], source: { label: 'GOV.UK: Lifetime ISA', url: 'https://www.gov.uk/lifetime-isa' },
  })
  a.push({
    id: 'cushion', kind: 'Cash flow', counts: false,
    script: { how: 'One transfer in your banking app.', lines: [
      'Move £250 from Easy-access savings to your Current account today.',
      'It covers Christmas week, which is the tightest point in your forecast.',
      'After payday on the 27th, move it back. Almanac will remind you.',
    ] },
    title: 'Keep a £250 cushion in your current account',
    detail: 'Christmas week falls just before payday. Moving £250 from easy-access savings now means you never touch an overdraft, and it goes back after the 27th.',
    yearly: 0, effort: '1 transfer',
    evidence: [], startBoost: 250,
  })
  return a
}
