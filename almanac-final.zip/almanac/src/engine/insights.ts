// Resilience score, the "two futures" projection, and the daily briefing.
import { mulberry32, normal } from '../lib/rng'
import { dayLabel, money, pct } from '../lib/format'
import type { Persona } from '../data/types'
import type { Forecast } from './forecast'
import type { Action } from './savings'
import type { Program } from './cards'

export interface ResiliencePart { key: string; label: string; earned: number; max: number; detail: string }

/**
 * 0–100. Five things that decide whether a bad month becomes a crisis.
 * Weights follow the order of priorities: don't go overdrawn, have a buffer,
 * no expensive debt, room to save, stop leaking money.
 */
export function resilience(o: {
  pAnyNeg: number
  monthsCovered: number
  cardDebt: number
  safe: number
  income: number
  doneYearly: number
  potentialYearly: number
}): { score: number; parts: ResiliencePart[] } {
  const parts: ResiliencePart[] = [
    { key: 'overdraft', label: 'Overdraft risk', max: 30, earned: 30 * Math.max(0, 1 - o.pAnyNeg / 0.4),
      detail: `${pct(o.pAnyNeg)} chance of going below £0 in the next 90 days` },
    { key: 'buffer', label: 'Emergency fund', max: 30, earned: 30 * Math.min(1, o.monthsCovered / 3),
      detail: `${o.monthsCovered.toFixed(1)} of 3 months of essentials` },
    { key: 'debt', label: 'Expensive debt', max: 15, earned: o.cardDebt > 0 ? Math.max(0, 15 - o.cardDebt / 100) : 15,
      detail: o.cardDebt > 0 ? `${money(o.cardDebt)} carried on cards` : 'None. Cards paid in full' },
    { key: 'room', label: 'Room to save', max: 15, earned: 15 * Math.min(1, o.safe / (0.1 * o.income)),
      detail: o.safe > 0 ? `${money(o.safe)} a month, target is 10% of income` : 'Nothing spare yet' },
    { key: 'leaks', label: 'Money leaking', max: 10, earned: 10 * (o.doneYearly / Math.max(1, o.doneYearly + o.potentialYearly)),
      detail: o.potentialYearly > 0 ? `${money(o.potentialYearly)} a year still overpaid or unclaimed` : 'Nothing left to fix' },
  ]
  parts.forEach((p) => (p.earned = Math.round(p.earned)))
  return { score: parts.reduce((s, p) => s + p.earned, 0), parts }
}

export const scoreBand = (s: number) => (s >= 75 ? 'Strong' : s >= 50 ? 'Steady' : s >= 30 ? 'Fragile' : 'At risk')

/**
 * Two futures over 10 years, in today's money.
 * "If nothing changes": savings sit where they are.
 * "With the plan": the monthly room goes to an emergency fund first, then a
 * Lifetime ISA (25% bonus) invested in a global index fund, then a Stocks & Shares ISA.
 */
export function twoFutures(p: Persona, monthly: number, years = 10) {
  const start = p.accounts.current + p.accounts.easyAccess + p.accounts.lisa + p.accounts.investments
  const target = p.essentials * 3
  const N = 400
  const mu = 0.05 / 12
  const sigma = 0.15 / Math.sqrt(12)
  const rng = mulberry32(17)
  const rows: number[][] = Array.from({ length: years * 12 + 1 }, () => [])
  for (let k = 0; k < N; k++) {
    let cash = start
    let invested = 0
    let lisaPaidThisYear = 0
    rows[0].push(start)
    for (let m = 1; m <= years * 12; m++) {
      if (m % 12 === 1) lisaPaidThisYear = 0
      const shock = Math.exp(mu - 0.5 * sigma * sigma + sigma * normal(rng))
      invested *= shock
      let left = monthly
      const toCash = cash < target ? Math.min(left * (cash < p.essentials ? 1 : 0.5), target - cash) : 0
      cash += toCash
      left -= toCash
      const toLisa = p.savingForFirstHome && p.age + m / 12 < 50 ? Math.min(left, 4000 / 12, 4000 - lisaPaidThisYear) : 0
      lisaPaidThisYear += toLisa
      invested += toLisa * 1.25 + (left - toLisa)
      rows[m].push(cash + invested)
    }
  }
  return rows
    .map((r, m) => {
      const s = r.sort((a, b) => a - b)
      return { month: m, p10: s[Math.floor(N * 0.1)], p50: s[Math.floor(N * 0.5)], p90: s[Math.floor(N * 0.9)], without: start }
    })
    .filter((_, m) => m % 3 === 0)
}

/** A short morning note, like a private banker would send. */
export function briefing(o: { forecast: Forecast; actions: Action[]; done: Set<string>; progs: Program[]; name: string }) {
  const days60 = o.forecast.days.slice(0, 60)
  const risk = o.forecast.days.reduce((w, d) => (d.pNeg > w.pNeg ? d : w))
  const low = days60.reduce((w, d) => (d.p50 < w.p50 ? d : w))
  const next = o.actions.filter((a) => !o.done.has(a.id) && a.yearly > 0).sort((a, b) => b.yearly - a.yearly)[0]
  const avios = o.progs.find((p) => p.scheme === 'Avios')
  const lines: string[] = []
  lines.push(risk.pNeg >= 0.05
    ? `Christmas week is your pinch point: a ${pct(risk.pNeg)} chance of dipping below £0 around ${dayLabel(risk.date)}.`
    : `You’re covered for the next 90 days. Your lowest point is about ${money(low.p50)} on ${dayLabel(low.date)}.`)
  if (next) lines.push(`Biggest win today: ${next.title.charAt(0).toLowerCase() + next.title.slice(1)}, worth ${money(next.yearly)} a year.`)
  if (avios) lines.push(`Your ${avios.balance.toLocaleString()} Avios go furthest on off-peak dates in late January.`)
  return lines
}
