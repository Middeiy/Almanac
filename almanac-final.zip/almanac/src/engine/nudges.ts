// Proactive heads-ups: what Almanac would tell you, and when, before anything goes wrong.
// Each one is tied to a date in the forecast, so the time machine can "deliver" them as it plays.
import { addDays } from '../lib/dates'
import { dayLabel, money, pct } from '../lib/format'
import type { Forecast } from './forecast'
import type { Learned } from './learn'
import type { Action } from './savings'
import type { CardPlan, Program } from './cards'

export interface Nudge {
  id: string
  day: number // index into the forecast
  date: Date
  tone: 'warn' | 'good' | 'info'
  title: string
  body: string
  actionId?: string
  actionLabel?: string
}

export function nudgesFor(o: { forecast: Forecast; learned: Learned; actions: Action[]; done: Set<string>; plan: CardPlan; progs: Program[]; safe: number }): Nudge[] {
  const days = o.forecast.days
  const out: Nudge[] = []
  const start = days[0].date

  // 1. Tight spells: warn 6 days before the first risky day of each spell
  let i = 0
  while (i < days.length) {
    if (days[i].pNeg >= 0.08) {
      let j = i
      let peak = days[i]
      while (j < days.length && days[j].pNeg >= 0.05) { if (days[j].pNeg > peak.pNeg) peak = days[j]; j++ }
      const at = Math.max(0, i - 6)
      const cushion = o.actions.find((a) => a.id === 'cushion' && !o.done.has(a.id))
      out.push({
        id: `tight-${i}`, day: at, date: days[at].date, tone: 'warn',
        title: `Heads up: ${dayLabel(peak.date)} looks tight`,
        body: `There’s a ${pct(peak.pNeg)} chance you dip below £0 that week. ${cushion ? 'Moving a £250 cushion across now would stop it.' : 'Your cushion is in place, so you should be fine.'}`,
        actionId: cushion?.id, actionLabel: cushion ? 'Move £250' : undefined,
      })
      i = j + 7
    } else i++
  }

  // 2. Payday: say what's safe to put away, the day it lands
  const salary = o.learned.recurring.find((r) => r.isIncome && r.period === 'monthly')
  if (salary) {
    for (let k = 0; k < days.length; k++) {
      if (days[k].date.getDate() !== salary.slot) continue
      out.push({
        id: `payday-${k}`, day: k, date: days[k].date, tone: o.safe > 0 ? 'good' : 'info',
        title: `Payday: ${money(salary.median)} landed`,
        body: o.safe > 0 ? `${money(o.safe)} is safe to put away this month without making a tight week more likely.` : 'Nothing is safe to put away yet. Bills come first this month.',
      })
    }
  }

  // 3. Bills about to leave that can be cut
  const bill = o.actions.find((a) => a.id === 'broadband' && !o.done.has(a.id))
  const bt = o.learned.recurring.find((r) => r.merchant === 'BT Broadband')
  if (bill && bt) {
    let k = 0
    while (k < days.length && days[k].date.getDate() !== bt.slot - 2) k++
    if (k < days.length) out.push({
      id: 'bill-bt', day: k, date: days[k].date, tone: 'info',
      title: `Broadband: ${money(Math.abs(bt.median))} leaves in 2 days`,
      body: `You’re on an out-of-contract price. One call could save about ${money(bill.yearly)} a year.`,
      actionId: bill.id, actionLabel: 'Show me the script',
    })
  }

  // 4. Welcome bonus deadline
  for (const b of o.plan.bonuses) {
    const left = b.card.bonus!.daysLeft
    const k = Math.max(0, Math.min(days.length - 1, left - 21))
    out.push({
      id: `bonus-${b.card.id}`, day: k, date: addDays(start, k), tone: b.onTrack ? 'good' : 'info',
      title: `${b.card.name}: 3 weeks left on the welcome bonus`,
      body: b.onTrack ? `You’re on course. Keep everyday spending on this card and the ${b.card.bonus!.points.toLocaleString()} points arrive on their own.` : 'You won’t reach it with normal spending. Don’t spend extra to chase it.',
    })
  }

  // 5. Off-peak points window
  const avios = o.progs.find((p) => p.scheme === 'Avios')
  if (avios) {
    const k = days.findIndex((d) => d.date.getMonth() === 0 && d.date.getDate() === 12)
    if (k >= 0) out.push({
      id: 'offpeak', day: k, date: days[k].date, tone: 'good',
      title: 'Off-peak season for points',
      body: `Late January is off-peak. Your ${avios.balance.toLocaleString()}+ Avios go further now than at half-term.`,
    })
  }
  return out.sort((a, b) => a.day - b.day)
}
