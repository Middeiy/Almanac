// Learn a cash-flow model from raw transactions.
// 1. Recurring items: same merchant, regular interval (weekly / monthly), stable day.
// 2. Everything else is "everyday spending", kept as an empirical distribution per weekday
//    so the simulation can replay real days rather than invent averages.
import type { Txn } from '../data/types'

export interface Recurring {
  merchant: string
  period: 'weekly' | 'monthly'
  /** day-of-month (monthly) or weekday 0–6 (weekly) */
  slot: number
  amounts: number[] // signed, sampled with replacement
  median: number
  mcc?: string
  isIncome: boolean
  isUC: boolean
  txnIds: string[]
}

export interface Learned {
  recurring: Recurring[]
  /** everything non-recurring, per weekday: list of daily net totals (spending and irregular income such as bank shifts) */
  everyday: number[][]
  /** same, spending only (used when simulating the loss of irregular income) */
  everydayOut: number[][]
  /** average monthly income over the history */
  monthlyIncome: number
  everydayIds: Set<string>
  clubcardSavedThisMonth: number
  tescoSpendMonthly: number
  sainsburysSpendMonthly: number
  lastAmazonPurchase: Date | null
}

const median = (xs: number[]) => {
  const s = [...xs].sort((a, b) => a - b)
  return s[Math.floor(s.length / 2)]
}
const mode = (xs: number[]) => {
  const c = new Map<number, number>()
  xs.forEach((x) => c.set(x, (c.get(x) ?? 0) + 1))
  return [...c.entries()].sort((a, b) => b[1] - a[1])[0]
}

export function learn(history: Txn[]): Learned {
  const byMerchant = new Map<string, Txn[]>()
  history.forEach((t) => {
    const k = `${t.merchant}|${t.amount >= 0 ? 'in' : 'out'}`
    byMerchant.set(k, [...(byMerchant.get(k) ?? []), t])
  })

  const recurring: Recurring[] = []
  const recurringIds = new Set<string>()

  for (const [, txns] of byMerchant) {
    if (txns.length < 2) continue
    const sorted = [...txns].sort((a, b) => a.date.getTime() - b.date.getTime())
    const gaps = sorted.slice(1).map((t, i) => Math.round((t.date.getTime() - sorted[i].date.getTime()) / 86_400_000))
    const g = median(gaps)
    const amounts = sorted.map((t) => t.amount)
    let period: Recurring['period'] | null = null
    let slot = 0
    if (g >= 6 && g <= 8) {
      const [dow, n] = mode(sorted.map((t) => t.date.getDay()))
      const span = (sorted[sorted.length - 1].date.getTime() - sorted[0].date.getTime()) / 86_400_000 / 7 + 1
      // must turn up in most weeks, otherwise it's irregular (e.g. occasional bank shifts)
      if (n / sorted.length >= 0.8 && sorted.length / span >= 0.75) { period = 'weekly'; slot = dow }
    } else if (g >= 27 && g <= 32) {
      const [dom, n] = mode(sorted.map((t) => t.date.getDate()))
      if (n / sorted.length >= 0.6) { period = 'monthly'; slot = dom }
    }
    if (!period) continue
    const r: Recurring = {
      merchant: sorted[0].merchant,
      period,
      slot,
      amounts,
      median: median(amounts),
      mcc: sorted[0].mcc,
      isIncome: amounts[0] > 0,
      isUC: /DWP UC/.test(sorted[0].info),
      txnIds: sorted.map((t) => t.id),
    }
    recurring.push(r)
    r.txnIds.forEach((id) => recurringIds.add(id))
  }

  // Everyday spending by weekday, including zero days
  const everyday: number[][] = [[], [], [], [], [], [], []]
  const everydayOut: number[][] = [[], [], [], [], [], [], []]
  const everydayIds = new Set<string>()
  const byDay = new Map<string, { dow: number; total: number; out: number }>()
  const start = history.reduce((m, t) => (t.date < m ? t.date : m), history[0].date)
  const end = history.reduce((m, t) => (t.date > m ? t.date : m), history[0].date)
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
    byDay.set(d.toDateString(), { dow: d.getDay(), total: 0, out: 0 })
  }
  history.forEach((t) => {
    if (recurringIds.has(t.id)) return
    everydayIds.add(t.id)
    const e = byDay.get(t.date.toDateString())
    if (e) { e.total += t.amount; if (t.amount < 0) e.out += t.amount }
  })
  byDay.forEach(({ dow, total, out }) => { everyday[dow].push(total); everydayOut[dow].push(out) })
  const days = (end.getTime() - start.getTime()) / 86_400_000 + 1
  const monthlyIncome = (history.filter((t) => t.amount > 0).reduce((s, t) => s + t.amount, 0) / days) * 30.4

  // rolling 30 days, so the figure is meaningful early in a calendar month
  const thisMonth = history.filter((t) => (end.getTime() - t.date.getTime()) / 86_400_000 < 30)
  const clubcardSavedThisMonth = thisMonth.reduce((s, t) => {
    const m = t.info.match(/CLUBCARD PRICES SAVED ([\d.]+)/)
    return s + (m ? parseFloat(m[1]) : 0)
  }, 0)
  const months = 3
  const spendAt = (re: RegExp) => -history.filter((t) => re.test(t.merchant) && t.amount < 0).reduce((s, t) => s + t.amount, 0) / months
  const amazon = history.filter((t) => /amazon/i.test(t.merchant) && !/prime/i.test(t.merchant))

  return {
    recurring,
    everyday,
    everydayOut,
    monthlyIncome,
    everydayIds,
    clubcardSavedThisMonth,
    tescoSpendMonthly: spendAt(/Tesco/),
    sainsburysSpendMonthly: spendAt(/Sainsbury/),
    lastAmazonPurchase: amazon.length ? amazon[amazon.length - 1].date : null,
  }
}
