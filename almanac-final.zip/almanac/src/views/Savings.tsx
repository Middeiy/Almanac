import { useState } from 'react'
import { useApp } from '../state'
import { dayLabel, money, money2 } from '../lib/format'
import type { Action, Kind } from '../engine/savings'
import { Badge, Button, Figure, Panel } from '../ui/kit'

const ORDER: Kind[] = ['Free money', 'Cards', 'Bills', 'Subscriptions', 'Shopping', 'Work perks', 'Cash flow']

export function ActionRow({ a, compact = false }: { a: Action; compact?: boolean }) {
  const { done, toggle, complete, persona, setScriptFor } = useApp()
  const [open, setOpen] = useState(false)
  const isDone = done.has(a.id)
  const txns = persona.history.filter((t) => a.evidence.includes(t.id)).slice(-5).reverse()
  return (
    <li className="py-3.5">
      <div className="flex items-start gap-4">
        <div className="min-w-0 flex-1">
          <p className={`text-[14.5px] font-medium ${isDone ? 'text-mute line-through decoration-1' : ''}`}>{a.title}</p>
          {!compact && <p className="mt-1 max-w-[70ch] text-[13.5px] leading-relaxed text-sub">{a.detail}</p>}
          <div className="mt-1.5 flex flex-wrap items-center gap-2 text-[12.5px] text-mute">
            <span>{a.effort}</span>
            {a.illustrative && !compact && <Badge>Estimate</Badge>}
            {a.source && <a href={a.source.url} target="_blank" rel="noreferrer" className="text-brand hover:underline">{a.source.label}</a>}
            {!compact && txns.length > 0 && <button onClick={() => setOpen(!open)} className="text-brand hover:underline">{open ? 'Hide transactions' : 'Show transactions'}</button>}
          </div>
          {open && (
            <ul className="mt-2 max-w-[520px] rounded-lg bg-bg px-3 py-1">
              {txns.map((t) => (
                <li key={t.id} className="flex justify-between border-b border-line py-1.5 text-[12.5px] last:border-0">
                  <span className="w-20 text-mute">{dayLabel(t.date, 'short')}</span>
                  <span className="flex-1 truncate">{t.info}</span>
                  <span className="tnum">{money2(t.amount)}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="w-28 shrink-0 text-right">
          {a.yearly > 0 ? <p className="figure text-[20px] text-gain">{money(a.yearly)}<span className="text-[12px] font-medium text-mute">/yr</span></p>
            : <p className="text-[12.5px] text-mute">{a.startBoost ? 'Protects your forecast' : 'Up to £1,000/yr'}</p>}
        </div>
        {a.script && !isDone && !compact && <Button size="sm" variant="ghost" onClick={() => setScriptFor(a.id)}>Do it for me</Button>}
        <Button size="sm" variant={isDone ? 'done' : 'secondary'} className="w-[112px]"
          onClick={() => (isDone ? toggle(a.id) : complete(a.id))}>
          {isDone ? 'Done' : 'Mark as done'}
        </Button>
      </div>
    </li>
  )
}

export function Savings() {
  const { actions, savedThisMonth, savedBreakdown, potentialYearly, done } = useApp()
  const doneYearly = actions.filter((a) => done.has(a.id) && a.counts).reduce((s, a) => s + a.yearly, 0)
  return (
    <div className="space-y-5">
      <header>
        <h1 className="text-[26px] font-semibold tracking-tight">Savings and discounts</h1>
        <p className="mt-1 text-[14px] text-sub">Everything here comes from your own transactions. Mark an action as done and it counts towards this month.</p>
      </header>
      <div className="grid grid-cols-3 gap-5">
        <Panel className="col-span-1" title="Saved this month">
          <p className="figure text-[44px] text-gain"><Figure value={savedThisMonth} fmt={money2} /></p>
          <ul className="mt-4 space-y-1.5">
            {savedBreakdown.map((b) => (
              <li key={b.label} className="flex justify-between gap-3 text-[13px]">
                <span className="truncate text-sub">{b.label}</span>
                <span className="tnum">{money2(b.amount)}</span>
              </li>
            ))}
          </ul>
        </Panel>
        <Panel className="col-span-2" title="This year">
          <div className="flex gap-10">
            <div>
              <p className="text-[13px] text-mute">Locked in</p>
              <p className="figure mt-2 text-[34px] text-gain"><Figure value={doneYearly} fmt={money} /></p>
            </div>
            <div>
              <p className="text-[13px] text-mute">Still available</p>
              <p className="figure mt-2 text-[34px]"><Figure value={potentialYearly} fmt={money} /></p>
            </div>
          </div>
          <div className="mt-5 flex h-2.5 gap-[2px] overflow-hidden rounded-full">
            {actions.filter((a) => a.counts && a.yearly > 0).sort((a, b) => b.yearly - a.yearly).map((a) => (
              <span key={a.id} title={`${a.title}: ${money(a.yearly)}/yr`} className="h-full transition-colors duration-500"
                style={{ flex: a.yearly, background: done.has(a.id) ? '#067A55' : '#D0D5DD' }} />
            ))}
          </div>
          <p className="mt-2 text-[12.5px] text-mute">Each segment is one action, sized by what it’s worth a year.</p>
        </Panel>
      </div>
      {ORDER.map((k) => {
        const list = actions.filter((a) => a.kind === k)
        if (!list.length) return null
        return (
          <Panel key={k} title={k}>
            <ul className="-my-3.5 divide-y divide-line">{list.map((a) => <ActionRow key={a.id} a={a} />)}</ul>
          </Panel>
        )
      })}
    </div>
  )
}
