import { useMemo, useState } from 'react'
import { useApp } from '../state'
import { money } from '../lib/format'
import { project } from '../engine/invest'
import { Badge, Button, Figure, Panel } from '../ui/kit'
import { GrowthChart } from '../ui/charts'

export function Invest() {
  const { safe, steps, pots, monthsCovered, emergencyTarget, persona, setView, done, complete } = useApp()
  const lisaStep = steps.flatMap((s) => s.to).find((t) => t.bonusRate > 0)
  const [monthly, setMonthly] = useState<number | null>(null)
  const m = monthly ?? lisaStep?.monthly ?? 100
  const rows = useMemo(() => project(m, 10, lisaStep ? 0.25 : 0), [m, lisaStep])
  const emergency = pots[1].amount

  return (
    <div className="space-y-5">
      <header>
        <h1 className="text-[26px] font-semibold tracking-tight">Investments and cash</h1>
        <p className="mt-1 text-[14px] text-sub">How much you can put away safely, where it should go first, and what it could grow to.</p>
      </header>

      <div className="grid grid-cols-3 gap-5">
        <Panel title="Safe to put away each month">
          {safe > 0 ? (
            <>
              <p className="figure text-[44px]"><Figure value={safe} fmt={money} /></p>
              <p className="mt-3 text-[13.5px] leading-relaxed text-sub">The most you can move out each month while keeping your chance of going below £0 under 10% for the next 90 days.</p>
            </>
          ) : (
            <>
              <p className="figure text-[44px] text-risk">Not yet</p>
              <p className="mt-3 text-[13.5px] leading-relaxed text-sub">Christmas week is too tight. Investing now would come out of money you need that week.</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {!done.has('cushion') && <Button size="sm" onClick={() => complete('cushion')}>Move a £250 cushion</Button>}
                <Button size="sm" variant="secondary" onClick={() => setView('time')}>Open the time machine</Button>
              </div>
            </>
          )}
        </Panel>

        <Panel className="col-span-2" title="Your plan" aside="The order a wealth manager would use">
          {steps.length ? (
            <ol className="space-y-4">
              {steps.map((s, i) => (
                <li key={i} className="flex gap-4">
                  <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-brand-soft text-[12px] font-semibold text-brand">{i + 1}</span>
                  <div className="flex-1">
                    <p className="text-[13px] font-medium text-mute">{s.when}</p>
                    <p className="mt-0.5 text-[15px] font-semibold">{s.to.map((t) => `${t.name}: ${money(t.monthly)}`).join(', then ')}</p>
                    {s.to.some((t) => t.bonusRate > 0) && <p className="mt-0.5 text-[13px] font-medium text-gain">+{money(s.to.reduce((a, t) => a + t.monthly * t.bonusRate, 0))} a month from the government bonus</p>}
                    <p className="mt-1 text-[13px] text-sub">{s.why}</p>
                  </div>
                </li>
              ))}
            </ol>
          ) : (
            <ol className="space-y-2 text-[14px] text-sub">
              <li><span className="font-medium text-ink">1. Clear the forecast.</span> No week where you’d go overdrawn.</li>
              <li><span className="font-medium text-ink">2. One month of essentials</span> in easy-access savings.</li>
              <li><span className="font-medium text-ink">3. Free money first:</span> Lifetime ISA, 25% bonus.</li>
              <li><span className="font-medium text-ink">4. Then a global index fund</span> in a Stocks and Shares ISA.</li>
            </ol>
          )}
        </Panel>
      </div>

      <Panel title={lisaStep ? 'Lifetime ISA in a global index fund' : 'What a global index fund could grow to'} aside="600 simulated markets, after inflation">
        <div className="mb-3 flex items-center gap-4">
          <label htmlFor="amt" className="text-[13.5px] text-sub">Each month</label>
          <input id="amt" type="range" min={25} max={400} step={25} value={m} onChange={(e) => setMonthly(+e.target.value)} className="max-w-[360px] flex-1 accent-[#067a55]" />
          <span className="figure w-20 text-[22px]">{money(m)}</span>
        </div>
        <GrowthChart rows={rows} />
        <p className="mt-3 max-w-[90ch] text-[12.5px] leading-relaxed text-mute">
          {lisaStep ? 'Includes the 25% government bonus. ' : ''}Assumes 5% a year after inflation with normal ups and downs. Guidance for people in {persona.name}’s situation, not personal advice. Investments can fall as well as rise. Since April 2026 the FCA’s targeted support rules let banks offer suggestions like this to customers with similar needs.
        </p>
      </Panel>

      <Panel title="How easy is your money to reach?" aside={<span>Emergency fund: <span className="tnum font-semibold text-ink">{money(emergency)}</span> of <span className="tnum">{money(emergencyTarget)}</span> ({monthsCovered.toFixed(1)} of 3 months) <Badge tone={monthsCovered >= 1 ? 'gain' : 'risk'}>{monthsCovered >= 1 ? 'Above 1 month' : 'Below 1 month'}</Badge></span>}>
        <div className="grid grid-cols-4 gap-4">
          {pots.map((p) => (
            <div key={p.name} className="rounded-xl bg-bg px-4 py-3">
              <p className="text-[13px] text-mute">{p.name}</p>
              <p className="figure mt-1.5 text-[24px]">{money(p.amount)}</p>
              <p className="mt-1.5 text-[12.5px] text-sub">{p.access}</p>
              <p className="text-[12.5px] text-mute">{p.role}</p>
            </div>
          ))}
        </div>
        <p className="mt-3 text-[13px] text-sub">Keep the emergency fund in easy-access savings, never invested. It has to be there on a bad week.</p>
      </Panel>
    </div>
  )
}
