import { useMemo } from 'react'
import { useApp } from '../state'
import { simulate } from '../engine/forecast'
import { Badge, Panel } from '../ui/kit'

export function HowItWorks() {
  const { persona, learned, actions, ai, overrides, startBoost } = useApp()
  const ms = useMemo(() => {
    const t = performance.now()
    simulate(persona, learned, { moves: new Set(), monthlySaving: 0, overrides, startBoost })
    return performance.now() - t
  }, [persona, learned, overrides, startBoost])
  const irregular = persona.history.filter((t) => /NHSP/.test(t.merchant)).length

  const steps = [
    { title: 'Read', body: `${persona.history.length} transactions over 90 days, in the UK Open Banking format NatWest’s Account and Transaction API returns.` },
    { title: 'Learn', body: `${learned.recurring.length} regular payments found by merchant and timing. ${irregular} irregular bank shifts kept as real, lumpy income.` },
    { title: 'Simulate', body: `400 possible futures × 90 days, replaying real days from history. Ran in ${Math.max(1, Math.round(ms))} ms just now, in your browser.` },
    { title: 'Decide', body: `${actions.length} actions, card routing, the resilience score and the plan. All rules, all checkable, no AI.` },
    { title: 'Explain', body: 'Qwen3-0.6B, on this laptop, reads the question and writes the reply. Every £ and % it writes is checked against the forecast.' },
  ]

  return (
    <div className="space-y-5">
      <header>
        <h1 className="text-[26px] font-semibold tracking-tight">How it works</h1>
        <p className="mt-1 text-[14px] text-sub">Every number on screen comes from this pipeline. The AI never does the maths. It only puts the maths into words.</p>
      </header>

      <Panel>
        <ol className="grid grid-cols-5 gap-3">
          {steps.map((s, i) => (
            <li key={s.title} className="relative rounded-xl bg-bg p-4">
              <p className="flex items-center gap-2 text-[14px] font-semibold">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-brand text-[12px] text-white">{i + 1}</span>{s.title}
              </p>
              <p className="mt-2 text-[12.5px] leading-relaxed text-sub">{s.body}</p>
              {i < steps.length - 1 && <span aria-hidden className="absolute top-1/2 -right-[11px] z-10 h-0 w-0 -translate-y-1/2 border-y-[6px] border-l-[8px] border-y-transparent border-l-[#c7ccd4]" />}
            </li>
          ))}
        </ol>
      </Panel>

      <div className="grid grid-cols-2 gap-5">
        <Panel title="The AI is checked before you see it" aside={
          <Badge tone={ai.state === 'online' ? 'gain' : 'mute'}>{ai.state === 'online' ? `${ai.model ?? 'Qwen3'} online, ${ai.device ?? 'local'}` : ai.state === 'checking' ? 'Checking…' : 'AI server off: built-in replies'}</Badge>
        }>
          <ol className="space-y-2 text-[13.5px] leading-relaxed text-sub">
            <li><span className="font-semibold text-ink">1. Understand.</span> Qwen turns “can I spend 100 quid tonight?” into {'{ amount: 100, when: today }'}. The amount must appear in your message, or it’s thrown away.</li>
            <li><span className="font-semibold text-ink">2. Calculate.</span> The forecast re-runs with the spend added. Same random numbers, so the only difference is the spend.</li>
            <li><span className="font-semibold text-ink">3. Write.</span> Qwen gets a short list of facts and the decision, and writes the reply.</li>
            <li><span className="font-semibold text-ink">4. Check.</span> Any £ or % not in the facts, or wording that contradicts the decision, and the reply is rejected and retried. If it fails again, you get the built-in answer from the same numbers.</li>
          </ol>
          <div className="mt-4 rounded-xl bg-bg p-3 font-mono text-[12px] leading-relaxed text-sub">
            <p>model: “…you could save £120 a year by…”</p>
            <p className="text-risk">rejected: figures not in the forecast: £120</p>
            <p>retry at lower temperature → passes → shown</p>
          </div>
          <p className="mt-3 text-[12.5px] text-mute">Why a small local model: your transactions never leave the device, it costs nothing to run, and the checks make a small model safe enough.</p>
        </Panel>

        <Panel title="Tested, not just demoed">
          <ul className="space-y-2.5 text-[13.5px] leading-relaxed text-sub">
            <li><span className="font-semibold text-ink">27 forecast checks</span> <span className="font-mono text-[12px]">npm run check</span>: spending more never lowers the risk, the lowest balance moves by exactly the amount spent, groceries are never called optional, and no reply ever contains NaN.</li>
            <li><span className="font-semibold text-ink">13 AI tests</span> <span className="font-mono text-[12px]">npm run test:llm</span>: invented figures are caught, amounts not in the message are rejected, contradictions of the decision are rejected, the server falls back cleanly.</li>
            <li><span className="font-semibold text-ink">Fixed seeds.</span> The same inputs always give the same answer, so the demo, the tests and the chat never disagree.</li>
          </ul>
        </Panel>
      </div>

      <div className="grid grid-cols-2 gap-5">
        <Panel title="What’s real, and what’s simulated">
          <table className="w-full text-[13px]">
            <tbody>
              {[
                ['Forecast, score, card plan, spend check', 'Real engine, running live', 'gain'],
                ['Chat replies', ai.state === 'online' ? 'Real local AI, checked' : 'Built-in engine (start the AI server for Qwen)', ai.state === 'online' ? 'gain' : 'mute'],
                ['UK rules (ISAs, Lifetime ISA, FCA)', 'Real, checked November 2026', 'gain'],
                ['Sam and his transactions', 'Synthetic, Open Banking format', 'mute'],
                ['Card terms, points values, trip prices', 'Illustrative estimates, labelled', 'mute'],
                ['Bank connection', 'Simulated consent flow', 'mute'],
              ].map(([a, b, t]) => (
                <tr key={a} className="border-b border-line-2 last:border-0">
                  <td className="py-2 pr-3 font-medium">{a}</td>
                  <td className="py-2 text-right"><Badge tone={t as 'gain' | 'mute'}>{b}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </Panel>

        <Panel title="From hackathon to NatWest app">
          <ol className="space-y-2 text-[13.5px] leading-relaxed text-sub">
            <li><span className="font-semibold text-ink">Data:</span> swap the synthetic file for NatWest’s Account and Transaction API. Same format, nothing else changes.</li>
            <li><span className="font-semibold text-ink">Permission:</span> investment suggestions run under the bank’s FCA targeted support permission (live since April 2026).</li>
            <li><span className="font-semibold text-ink">Cost:</span> the forecast runs on the phone; the 0.6B model can run on-device or on one small server.</li>
            <li><span className="font-semibold text-ink">Next:</span> calibrate the resilience score against real outcomes (missed payments, overdraft use) before using it for anything that matters.</li>
          </ol>
        </Panel>
      </div>
    </div>
  )
}
