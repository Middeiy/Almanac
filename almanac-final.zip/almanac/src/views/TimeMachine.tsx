import { useEffect, useMemo, useRef, useState } from 'react'
import { useApp } from '../state'
import { simulate } from '../engine/forecast'
import { twoFutures } from '../engine/insights'
import { addDays } from '../lib/dates'
import { dayLabel, money, pct } from '../lib/format'
import { animate, reducedMotion } from '../lib/motion'
import { ForecastChart, FuturesChart } from '../ui/charts'
import { Badge, Button, Panel } from '../ui/kit'

type Mode = 'days' | 'years'

const SHOCKS = [
  { id: 'shifts', label: 'Bank shifts stop', detail: 'No NHSP shifts for 3 months' },
  { id: 'boiler', label: 'A £400 repair on 1 Dec', detail: 'Boiler, car or phone' },
  { id: 'rent', label: 'Rent goes up 5% in January', detail: '+£33 a month' },
] as const

export function TimeMachine() {
  const { persona, learned, forecast, overrides, startBoost, actions, done, complete, toggle, pots, planSafe, nudges } = useApp()
  const [mode, setMode] = useState<Mode>('days')
  const [day, setDay] = useState(0)
  const [year, setYear] = useState(10)
  const [shocks, setShocks] = useState<Set<string>>(new Set())
  const playing = useRef(false)
  // proactive heads-ups "arrive" as the cursor passes their date
  const [pops, setPops] = useState<typeof nudges>([])
  const prevDay = useRef(0)
  useEffect(() => {
    const from = prevDay.current
    prevDay.current = day
    if (day <= from) return
    const fresh = nudges.filter((n) => n.day > from && n.day <= day)
    if (!fresh.length) return
    setPops((p) => [...p, ...fresh].slice(-2))
    fresh.forEach((n) => window.setTimeout(() => setPops((p) => p.filter((x) => x.id !== n.id)), 3800))
  }, [day, nudges])

  const shocked = useMemo(() => {
    if (!shocks.size) return null
    return simulate(persona, learned, {
      moves: new Set(), monthlySaving: 0, overrides, startBoost,
      shocks: {
        noIrregularIncome: shocks.has('shifts'),
        oneOffs: shocks.has('boiler') ? [{ date: new Date(2026, 11, 1), amount: -400 }] : [],
        rentRise: shocks.has('rent') ? 0.05 : 0,
      },
    })
  }, [shocks, persona, learned, overrides, startBoost])
  const shown = shocked ?? forecast
  const d = shown.days[day]
  const events = learned.recurring.filter((r) => r.period === 'monthly' && r.slot === d.date.getDate())
  const low = shown.days.reduce((w, x) => (x.p10 < w.p10 ? x : w))
  const emergency = pots[1].amount
  const covered = -Math.min(0, low.p10) <= emergency
  const futures = useMemo(() => twoFutures(persona, planSafe), [persona, planSafe])
  const at = futures.reduce((b, r) => (Math.abs(r.month - year * 12) < Math.abs(b.month - year * 12) ? r : b))

  const play = () => {
    if (playing.current) return
    playing.current = true
    if (reducedMotion()) { setDay(89); playing.current = false; return }
    const o = { v: 0 }
    animate(o, { v: 89, duration: 6000, ease: 'inOutSine', onUpdate: () => setDay(Math.round(o.v)), onComplete: () => { playing.current = false } })
  }
  const playYears = () => {
    if (reducedMotion()) { setYear(10); return }
    const o = { v: 0 }
    animate(o, { v: 10, duration: 3500, ease: 'inOutSine', onUpdate: () => setYear(Math.round(o.v * 4) / 4) })
  }

  const readout = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (readout.current && !reducedMotion() && events.length) animate(readout.current, { scale: [1, 1.015, 1], duration: 400, ease: 'outQuad' })
  }, [day]) // eslint-disable-line

  const levers = actions.filter((a) => a.overrides || a.startBoost)

  return (
    <div className="space-y-5">
      <header className="flex items-end justify-between">
        <div>
          <h1 className="text-[26px] font-semibold tracking-tight">Time machine</h1>
          <p className="mt-1 text-[14px] text-sub">Travel forward through your money. See trouble coming, test what-ifs, and compare two futures.</p>
        </div>
        <div className="flex rounded-lg border border-line bg-surface p-1" role="tablist">
          {(['days', 'years'] as Mode[]).map((m) => (
            <button key={m} role="tab" aria-selected={mode === m} onClick={() => setMode(m)}
              className={`whitespace-nowrap rounded-md px-4 py-1.5 text-[13.5px] font-medium ${mode === m ? 'bg-ink text-white' : 'text-sub hover:text-ink'}`}>
              {m === 'days' ? 'Next 90 days' : 'Next 10 years'}
            </button>
          ))}
        </div>
      </header>

      {mode === 'days' ? (
        <>
          <Panel className="relative">
            <div className="pointer-events-none absolute top-5 left-[22%] z-10 w-[330px] space-y-2">
              {pops.map((n) => <Notification key={n.id} n={n} />)}
            </div>
            <div className="grid grid-cols-[1fr_250px] gap-6">
              <div>
                <ForecastChart days={shown.days} before={shocked ? forecast.days : undefined} beforeLabel="Without the what-ifs" cursor={day} height={260} marks={nudges.map((n) => ({ day: n.day, tone: n.tone }))} />
              </div>
              <div ref={readout} className="flex flex-col rounded-xl bg-[#24123F] p-4 text-white">
                <p className="text-[12.5px] text-[#B9AED3]">{day === 0 ? 'Today' : `In ${day} day${day > 1 ? 's' : ''}`}</p>
                <p className="mt-0.5 text-[18px] font-semibold">{dayLabel(d.date)}</p>
                <p className="mt-4 text-[12.5px] text-[#B9AED3]">Likely balance</p>
                <p className="figure mt-1 text-[34px]">{money(d.p50)}</p>
                <p className="tnum mt-1 text-[12.5px] text-[#B9AED3]">Range {money(d.p10)} to {money(d.p90)}</p>
                <p className={`mt-3 text-[13px] font-medium ${d.pNeg >= 0.1 ? 'text-[#FFB4A8]' : 'text-[#5EE0B5]'}`}>{pct(d.pNeg)} chance below £0</p>
                <div className="mt-auto border-t border-white/10 pt-3 text-[12.5px]">
                  {events.length ? events.map((e) => (
                    <p key={e.merchant} className="flex justify-between"><span>{e.merchant}</span><span className="tnum">{e.median > 0 ? '+' : ''}{money(e.median)}</span></p>
                  )) : <p className="text-[#B9AED3]">No regular payments this day</p>}
                </div>
              </div>
            </div>
            <div className="mt-4 flex items-center gap-4">
              <Button size="sm" onClick={() => { prevDay.current = -1; setDay(0); play() }}>Play the next 90 days</Button>
              <input type="range" min={0} max={89} value={day} onChange={(e) => setDay(+e.target.value)} aria-label="Day" className="flex-1 accent-[#4b2a86]" />
              <span className="tnum w-24 text-right text-[13px] text-sub">{dayLabel(addDays(shown.days[0].date, day), 'short')}</span>
            </div>
          </Panel>

          <div className="grid grid-cols-2 gap-5">
            <Panel title="What if…" aside="Stress-test your next 90 days">
              <ul className="space-y-2">
                {SHOCKS.map((s) => {
                  const on = shocks.has(s.id)
                  return (
                    <li key={s.id}>
                      <button onClick={() => setShocks((x) => { const n = new Set(x); if (n.has(s.id)) n.delete(s.id); else n.add(s.id); return n })}
                        aria-pressed={on}
                        className={`flex w-full items-center justify-between rounded-xl border px-4 py-3 text-left transition-colors ${on ? 'border-[#f4c7c2] bg-risk-soft' : 'border-line hover:border-[#c7ccd4]'}`}>
                        <span>
                          <span className="block text-[14px] font-medium">{s.label}</span>
                          <span className="block text-[12.5px] text-mute">{s.detail}</span>
                        </span>
                        <span className={`text-[12.5px] font-medium ${on ? 'text-risk' : 'text-mute'}`}>{on ? 'On' : 'Off'}</span>
                      </button>
                    </li>
                  )
                })}
              </ul>
              {shocked && (
                <div className={`mt-4 rounded-xl px-4 py-3 text-[13.5px] leading-relaxed ${covered ? 'bg-gain-soft text-[#05543b]' : 'bg-risk-soft text-[#7a271a]'}`}>
                  <p className="font-semibold">{pct(shocked.pAnyNeg)} chance of going below £0 (was {pct(forecast.pAnyNeg)}).</p>
                  <p>In a bad case your current account dips to {money(low.p10)} around {dayLabel(low.date)}.{' '}
                    {covered
                      ? `Your ${money(emergency)} emergency fund covers the gap. Move what you need across before then: this is exactly what it’s for, and you’d avoid overdraft charges.`
                      : `That’s more than your ${money(emergency)} emergency fund. Take the actions on the right now, and if it happens, talk to free debt advice early (see Privacy and safety).`}
                  </p>
                </div>
              )}
            </Panel>

            <Panel title="Actions that change this" aside={`${pct(forecast.pAnyNeg)} chance below £0 now`}>
              <ul className="divide-y divide-line">
                {levers.map((a) => (
                  <li key={a.id} className="flex items-center gap-3 py-3">
                    <span className="flex-1">
                      <span className="block text-[14px] font-medium">{a.title}</span>
                      <span className="block text-[12.5px] text-mute">{a.yearly > 0 ? `${money(a.yearly)} a year` : 'Moves the low point up'}</span>
                    </span>
                    <Button size="sm" variant={done.has(a.id) ? 'done' : 'secondary'} onClick={() => (done.has(a.id) ? toggle(a.id) : complete(a.id))}>
                      {done.has(a.id) ? 'Applied' : 'Apply'}
                    </Button>
                  </li>
                ))}
              </ul>
            </Panel>
          </div>
        </>
      ) : (
        <>
          <section className="rounded-2xl bg-[#24123F] p-6 text-white">
            <div className="flex items-start justify-between gap-6">
              <div>
                <p className="text-[13px] text-[#B9AED3]">In {year === 0 ? 'today' : `${2026 + Math.round(year)}`}, {year} year{year === 1 ? '' : 's'} from now</p>
                <div className="mt-2 flex items-end gap-8">
                  <div>
                    <p className="text-[12.5px] text-[#5EE0B5]">With the plan</p>
                    <p className="figure mt-1 text-[44px] text-[#5EE0B5]">{money(at.p50)}</p>
                  </div>
                  <div>
                    <p className="text-[12.5px] text-[#B9AED3]">If nothing changes</p>
                    <p className="figure mt-1 text-[30px] text-[#D9D1EA]">{money(at.without)}</p>
                  </div>
                  <div>
                    <p className="text-[12.5px] text-[#B9AED3]">Difference</p>
                    <p className="figure mt-1 text-[30px]">+{money(at.p50 - at.without)}</p>
                  </div>
                </div>
              </div>
              <Button size="sm" variant="secondary" onClick={playYears}>Replay</Button>
            </div>
            <div className="mt-5"><FuturesChart rows={futures} cursorYear={year} /></div>
            <input type="range" min={0} max={10} step={0.25} value={year} onChange={(e) => setYear(+e.target.value)} aria-label="Years ahead" className="mt-3 w-full accent-[#5EE0B5]" />
          </section>
          <div className="grid grid-cols-2 gap-5">
            <Panel title="The plan behind the green line">
              <ol className="space-y-2.5 text-[13.5px] text-sub">
                <li><span className="font-medium text-ink">1. Take every action Almanac found.</span> That frees about <span className="tnum font-semibold text-ink">{money(planSafe)}</span> a month without cutting what you enjoy.</li>
                <li><span className="font-medium text-ink">2. Emergency fund to 3 months</span> ({money(persona.essentials * 3)}) in easy-access savings. Never invested.</li>
                <li><span className="font-medium text-ink">3. Lifetime ISA</span> for a first home: 25% government bonus on up to £4,000 a year, held in a global index fund.</li>
                <li><span className="font-medium text-ink">4. Anything above that</span> into a Stocks and Shares ISA, also a global index fund.</li>
              </ol>
            </Panel>
            <Panel title="Read this before you rely on it" aside={<Badge tone="risk">Capital at risk</Badge>}>
              <p className="text-[13px] leading-relaxed text-sub">
                This is an illustration in today’s money, not a promise. It assumes 5% a year growth after inflation with normal ups and downs, and shows where 8 in 10 simulated outcomes land. Investments can fall as well as rise and you could get back less than you put in. Lifetime ISA money withdrawn for anything other than a first home up to £450,000 or after age 60 has a 25% charge, so you can get back less than you paid in. This is guidance, not personal advice.
              </p>
            </Panel>
          </div>
        </>
      )}
    </div>
  )
}

function Notification({ n }: { n: { title: string; body: string; tone: string } }) {
  const ref = useRef<HTMLDivElement>(null)
  useEffect(() => {
    if (ref.current && !reducedMotion()) animate(ref.current, { opacity: [0, 1], translateY: [-14, 0], scale: [0.96, 1], duration: 420, ease: 'outBack(1.4)' })
  }, [])
  return (
    <div ref={ref} className="rounded-2xl border border-white/60 bg-white/95 px-4 py-3 shadow-[0_16px_40px_-12px_rgba(16,24,40,.35)] backdrop-blur">
      <div className="flex items-center justify-between text-[11.5px] text-mute">
        <span className="font-semibold text-ink">Almanac</span><span>now</span>
      </div>
      <p className={`mt-0.5 text-[13.5px] font-semibold ${n.tone === 'warn' ? 'text-risk' : n.tone === 'good' ? 'text-gain' : 'text-ink'}`}>{n.title}</p>
      <p className="text-[12.5px] leading-snug text-sub">{n.body}</p>
    </div>
  )
}
