export const DAY = 86_400_000

// Demo "today". Fixed so the forecast always lands on the same story.
export const TODAY = new Date(2026, 10, 8) // Sun 8 Nov 2026

export function addDays(d: Date, n: number) {
  const x = new Date(d)
  x.setDate(x.getDate() + n)
  return x
}
export function iso(d: Date) {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}
export function sameDay(a: Date, b: Date) {
  return iso(a) === iso(b)
}
export function daysBetween(a: Date, b: Date) {
  return Math.round((b.getTime() - a.getTime()) / DAY)
}
