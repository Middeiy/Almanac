const gbp0 = new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP', maximumFractionDigits: 0 })
const gbp2 = new Intl.NumberFormat('en-GB', { style: 'currency', currency: 'GBP', minimumFractionDigits: 2, maximumFractionDigits: 2 })

export const money = (n: number) => gbp0.format(Math.round(n))
export const money2 = (n: number) => gbp2.format(n)
export const pct = (p: number) => `${Math.round(p * 100)}%`

export function dayLabel(d: Date, style: 'long' | 'short' = 'long') {
  return d.toLocaleDateString('en-GB', style === 'long' ? { weekday: 'short', day: 'numeric', month: 'short' } : { day: 'numeric', month: 'short' })
}
