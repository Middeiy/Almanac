# Almanac: the wealth manager for everyone else

Wealthy people have someone who checks every bill, plans for bad months and makes every pound work.
Almanac does that for everyone else, from their own bank transactions, in plain English.

Built for GreatUniHack 2026: the NatWest financial-resilience challenge, plus the overall prize. Designed for a laptop screen, 1280px wide or more.

## Run it

```bash
npm install
npm run dev                                   # http://localhost:5173

# optional, second terminal: live AI in the chat, powered by Qwen3-0.6B running on your own machine
npm run ai:setup                              # once: installs transformers + torch
npm run ai                                    # downloads Qwen/Qwen3-0.6B on first run (about 1.2 GB), then serves :8787
```

Without the AI server, the chat answers from the built-in engine, so the demo works with no internet.
`npx vite build -c vite.single.config.ts` produces a single self-contained `dist-single/index.html`.

**Before presenting:** click **Reset demo** at the bottom of the left menu. It brings back the opening screens and clears everything.

## Features

| | |
|---|---|
| **Open Banking onboarding** | Consent screen (read-only, 90 days, revocable), then a live "getting to know your money" readout built from the real engine numbers. |
| **Resilience score** | 0–100 across overdraft risk, emergency fund, expensive debt, room to save and money leaking. It moves as you take actions ("+19 since you started"). |
| **Daily briefing** | Three plain-English lines, like a private banker's morning note. |
| **Time machine: 90 days** | Ensemble forecast (400 simulated futures). Press **Play** to sweep through the next 90 days with live readouts. **What if** stress tests: bank shifts stop, a £400 repair, a rent rise. It tells you whether your emergency fund covers the gap. |
| **Time machine: 10 years** | Two futures, "if nothing changes" vs "with the plan", with an uncertainty band and capital-at-risk wording. |
| **Savings and discounts** | Evidence-linked actions with £/year values. "Mark as done" updates the saved-this-month figure, the forecast and the score, with Undo. |
| **Cards and points** | Add any card (dummy templates or your own), best card per spending category, points valued two ways, welcome-bonus tracker (only if normal spending reaches it), interest warnings, off-peak trip idea. |
| **Investments and cash** | Room to save, the order a wealth manager would use, liquidity by access speed, 10-year projection. |
| **Wealth-manager chat** | Grounded in the same numbers. Takes actions, opens screens, reacts when you add a card. Read aloud and voice input (Chrome/Edge). |
| **Spend checker (Overview)** | Amount, what on, when → instant verdict (go / careful / hold off / it's a need), before-and-after balance chart, and the safe amount. No typing in the chat needed. |
| **Heads-ups** | Proactive warnings tied to dates: a tight week six days before it happens, payday "here's what's safe to put away", a bill about to leave that you're overpaying, bonus deadlines, off-peak points season. They pop up as phone-style notifications while the time machine plays. |
| **Do it for me** | For every saving: the exact words to say on the phone (or taps in the app), ready to copy. "Text PAC to 65075" for SIM-only, a retention script for broadband. |
| **Charts in the chat** | Spend questions come back with a before-and-after balance chart drawn inside the reply. |
| **How it works page** | The pipeline (read → learn → simulate → decide → explain), live simulation timing, AI server status, the guard that rejects invented numbers, test counts, and what's real vs simulated. |
| **Speaker notes** | Press **N** for what to say, what to click and likely judge questions on each screen. |
| **"Should I spend this?"** | Ask "I want to spend £100 out tonight, should I?" or "is it worth spending £50 on groceries?". The forecast is re-run with that spend added, and the answer says what it does to your chance of going below £0, what would make it safe, and which saving to take to afford it. |
| **⌘K / Ctrl+K** | Jump anywhere, do any action, or ask a question. |
| **Accessibility** | Simple view (four plain sentences with big buttons), larger text, read aloud, reduced-motion support, keyboard navigation. |
| **Privacy and safety** | Promises, guidance vs advice, the UK rules it follows, data download/delete, free debt-help signposting. |

## Pitch (3 minutes)

**0:00 The problem (on the opening screen).** "1 in 4 UK adults, 12.9 million, have low financial resilience: one bad month from trouble. £24 billion of support goes unclaimed every year. Wealthy people pay someone to watch every pound. Everyone else gets a banking app that tells them what they already spent."

**0:25 Connect.** Connect your bank → consent → the readout ends on "resilience 38 out of 100". "Sam is a healthcare assistant on £24k. Nobody has ever looked at his whole picture."

**0:50 The wealth manager.** Overview: score breakdown and briefing. Spend checker: £100, going out, today → "Hold off": risk goes from 23% to 41%, and the chart shows why. Click **What should I do first?** In the chat: **Do it: £250 cushion**. The score jumps, room to save unlocks.

**1:40 Financial time travel.** Time machine → **Play the next 90 days**: heads-ups pop up before each problem. Turn on **Bank shifts stop**: "your emergency fund covers it". **Next 10 years**: £1,840 vs about £30,000.

**2:20 It actually does things.** Savings → broadband → **Do it for me**: the exact phone script. Cards → **Add a card** → Aurora Rewards: the chat values the points instantly.

**2:40 Trust.** How it works: "The AI never does the maths. A 0.6B model on this laptop writes the words; a checker throws out any number the forecast didn't produce. 27 forecast checks, 13 AI tests." Simple view for anyone who finds banking apps hard. "Built to run inside the NatWest app, under FCA targeted support."

## Questions judges will ask

- **Is the data real?** No. Sam is synthetic, in the exact Open Banking format NatWest's API returns. Swapping it in changes one file.
- **Is the chat really AI?** Yes, when `npm run ai` is running (the chat header says so). It parses the question and writes the reply. Every £ and % it writes is checked against the forecast; failures fall back to the built-in answer. Without the server you see the built-in answers, and the header says that too.
- **How accurate is the forecast?** It replays Sam's real days, 400 times. It's a range, not a promise, and it shows the range. It hasn't been back-tested against real outcomes yet. That's the first thing to do with real data.
- **Why these resilience weights?** Ordered by priority (don't go overdrawn → buffer → no expensive debt → room to save → leaks). Not yet calibrated; next step is fitting them to real missed-payment data.
- **Is this legal?** As guidance, yes: no named funds, no credit recommendations, risk warnings everywhere. To offer investment suggestions to real customers it must run under an FCA-authorised firm's targeted support permission, e.g. NatWest's.
- **Why would NatWest build this?** Customers who don't hit an overdraft cost less, trust more and stay. And it's exactly what Consumer Duty asks banks to do.

## UK compliance choices

- **Guidance, not advice.** It never names a fund, provider or product. Investment suggestions are framed as the FCA's targeted support (live from 6 April 2026), which must run under an authorised firm's permissions (e.g. a bank).
- **No credit broking.** It only optimises cards the user already holds. It never suggests applying for credit, borrowing, BNPL, or spending to earn points.
- **Risk warnings** wherever investing appears: capital at risk, illustrations not promises.
- **ISA rules as of Nov 2026:** £20k allowance; £12k cash ISA cap for under-65s from 6 April 2027. Lifetime ISA: open 18–39, £4k/yr, 25% bonus, first home ≤ £450k or age 60, 25% charge otherwise (20% for first homes above £450k since 29 Oct 2026). Replaced for new savers by the First Time Buyer ISA from April 2029.
- **Data:** read-only Open Banking (AISP), 90-day consent, UK GDPR purpose limitation, export and delete.
- **Consumer Duty:** debt-first ordering, emergency fund never invested, free help signposted (MoneyHelper, StepChange, National Debtline, Citizens Advice, Breathing Space).

## How it works

- `src/data/personas.ts`: 90 days of synthetic transactions in UK Open Banking `OBTransaction` shape.
- `src/engine/learn.ts`: recurring-payment detection and empirical day-of-week spending.
- `src/engine/forecast.ts`: Monte Carlo cash-flow (fixed seed, so action effects aren't noise), shocks, safe-to-save bisection.
- `src/engine/insights.ts`: resilience score, two-futures projection, briefing.
- `src/engine/cards.ts`, `savings.ts`, `invest.ts`: optimisers.
- `src/ai/chat.ts`: chat engine, the built-in replies, and the client for the AI server.
- `src/ai/whatif.ts`: the "should I spend this?" tool. Re-runs the forecast with the spend added, picks a verdict, finds the safe amount and the cost-cutting actions.
- `llm/`: the Qwen3-0.6B server (Python, `transformers`). `qwen.py` loads the model, `prompts.py` holds the persona and prompts, `guards.py` checks the model's output, `service.py` and `server.py` are the two endpoints.

## The AI agent (Qwen3-0.6B)

```
 "I want to spend £100 out tonight, should I?"
        │
        ▼  POST /api/intent        Qwen reads it: { intent: spend_check, amount: 100, category: dining, days_from_now: 0 }
        │
        ▼  whatif.ts (browser)     Same Monte Carlo as the dashboard + a £100 one-off.
        │                          "Chance of going below £0: 23% → 41%. Lowest balance £192 → £92 (Sat 26 Dec)."
        │                          Verdict (go / careful / hold / essential), safe amount, £250-cushion scenario,
        │                          and the open savings actions that fit the spend.
        ▼  POST /api/chat          Qwen writes the recommendation from those facts, in Almanac's voice.
        │
        ▼  guards.py               Rejects the reply if it quotes a £ or % figure that is not in the facts,
                                   or contradicts the verdict. One cooler retry, then the built-in reply is used.
```

Design choices, because a 0.6B model is small:

- **The model never does arithmetic.** All numbers come from the forecast engine; the model only phrases them. The decision (hold off / careful / go / it's a need) is made by the engine and handed to the model as an instruction.
- **Numbers are checked.** Every money amount or percentage in a reply must appear in the facts it was given.
- **Its reading of your question is checked too.** The amount it extracts must really be in your message; otherwise the app's own regex reading is used.
- **It fails safe.** Server off, slow (90 s limit), or a failed check: you get the built-in reply, which is written from the same numbers. The chat header says "Qwen3 AI on this laptop" when the AI server is reachable, and "AI server off" when it is not.
- **Thinking mode is off** (`enable_thinking=False`), so replies take a few seconds on a laptop CPU. Use a GPU if you have one; it is picked up automatically. `QWEN_MODEL=Qwen/Qwen3-1.7B npm run ai` swaps in a larger Qwen if you want better wording.

## Checks

```bash
npm run check       # the what-if maths against the real engine (no browser, no model)
npm run test:llm    # the guards, prompts and HTTP endpoints, with the model stubbed
```
